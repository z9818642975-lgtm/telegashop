# bot/constants/__init__.py
from .callbacks_common import *
from .callbacks_client import *
from .callbacks_operator import *
from .callbacks_admin import *
