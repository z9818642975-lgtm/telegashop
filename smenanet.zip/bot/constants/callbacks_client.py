# bot/constants/callbacks_client.py
from __future__ import annotations

from aiogram.filters.callback_data import CallbackData

# =========================================================
# CLIENT — MENU / CATALOG
# =========================================================

class CatalogOpen(CallbackData, prefix="client_catalog_open"):
    pass


class ProductOpen(CallbackData, prefix="client_product_open"):
    product_id: int


# =========================================================
# CLIENT — CART
# =========================================================

class ClientCartOpen(CallbackData, prefix="client_cart_open"):
    pass


class ClientCartClear(CallbackData, prefix="client_cart_clear"):
    pass


class ClientCartCheckout(CallbackData, prefix="client_cart_checkout"):
    pass


# =========================================================
# CLIENT — ITEMS / QUANTITY
# =========================================================

class ClientItemQty(CallbackData, prefix="client_item_qty"):
    item_id: int
    qty: int


class ClientItemRemove(CallbackData, prefix="client_item_remove"):
    item_id: int


# =========================================================
# CLIENT — DELIVERY
# =========================================================

class ClientDeliveryPickup(CallbackData, prefix="client_delivery_pickup"):
    pass


class ClientDeliveryCourier(CallbackData, prefix="client_delivery_courier"):
    pass


class ClientDeliveryPrice(CallbackData, prefix="client_delivery_price"):
    method: str


# =========================================================
# CLIENT — PAYMENT
# =========================================================

class ClientPayBank(CallbackData, prefix="client_pay_bank"):
    bank_id: int


class ClientPaySBP(CallbackData, prefix="client_pay_sbp"):
    pass


class ClientPaymentDone(CallbackData, prefix="client_payment_done"):
    pass


class ClientPaymentCancel(CallbackData, prefix="client_payment_cancel"):
    pass


class PaymentMethodCB(CallbackData, prefix="pay"):
    method: str
# =========================================================
# CLIENT — PICKUP / CONFIRM
# =========================================================

class ClientPickupSelect(CallbackData, prefix="client_pickup_select"):
    pickup_id: int


class ClientPickupConfirm(CallbackData, prefix="client_pickup_confirm"):
    order_id: int
