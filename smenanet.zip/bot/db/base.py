# bot/db/base.py
#db\base.py
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass



