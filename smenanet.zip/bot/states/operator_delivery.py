# bot/states/operator_delivery.py
from aiogram.fsm.state import StatesGroup, State


class OperatorDeliveryFSM(StatesGroup):
    comment = State()
    photo = State()

