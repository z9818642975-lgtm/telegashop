# bot/routers/payment.py
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession
from bot.utils.safe_edit import safe_edit_text

from bot.fsm.checkout_fsm import CheckoutFSM
from bot.dao.orders_dao import OrdersDAO
from bot.models.enums import OrderStatus
from bot.utils.safe_edit import safe_edit_text

router = Router(name="client_payment")


@router.callback_query(
    CheckoutFSM.payment,
    True,
)
async def choose_payment(
    cb: CallbackQuery,
    state: FSMContext,
    session: AsyncSession,
    user,
):
    method = callback_data.method

    order = await OrdersDAO(session).get_active(user.id)
    order.payment_method = method
    order.status = OrderStatus.WAITING_PAYMENT
    await session.flush()

    await state.set_state(CheckoutFSM.wait_check)

    await safe_edit_text(None, text="📎 Пришлите чек")


@router.message(CheckoutFSM.wait_check)
async def receive_check(
    message: Message,
    state: FSMContext,
    session: AsyncSession,
    user,
):
    order = await OrdersDAO(session).get_active(user.id)
    order.status = OrderStatus.WAITING_OPERATOR
    await session.flush()

    await state.clear()

    await message.answer("⏳ Чек передан оператору")








