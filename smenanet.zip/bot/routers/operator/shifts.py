from aiogram import Router
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.operator_shift_dao import OperatorShiftDAO

router = Router(name="operator_shifts")


@router.message(lambda m: m.text == "🟢 Начать смену")
async def start_shift(message: Message, session: AsyncSession):
    dao = OperatorShiftDAO(session)

    await dao.start_shift(
        operator_id=message.from_user.id,
        pickup_address="Адрес будет указан клиентом",
    )

    await message.answer("✅ Смена начата")
