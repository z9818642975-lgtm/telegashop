$ErrorActionPreference = "Stop"

# 🔒 ЖЁСТКО UTF-8 БЕЗ BOM
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

$adminPrefix = "А "
$operatorPrefix = "О "

$adminPaths = @(
    "bot\keyboards\admin",
    "bot\routers\admin"
)

$operatorPaths = @(
    "bot\keyboards\operator",
    "bot\routers\operator"
)

function Normalize-Files($paths, $prefix) {
    foreach ($path in $paths) {
        Get-ChildItem -Path $path -Recurse -Filter *.py | ForEach-Object {

            $file = $_.FullName
            $content = [System.IO.File]::ReadAllText($file, $utf8NoBom)
            $original = $content

            # text="..."
            $content = $content -replace 'text="([^"]+)"', {
                param($m)
                $text = $m.Groups[1].Value
                if ($text.StartsWith($prefix)) { return $m.Value }
                return 'text="' + $prefix + $text + '"'
            }

            # F.text == "..."
            $content = $content -replace 'F\.text\s*==\s*"([^"]+)"', {
                param($m)
                $text = $m.Groups[1].Value
                if ($text.StartsWith($prefix)) { return $m.Value }
                return 'F.text == "' + $prefix + $text + '"'
            }

            if ($content -ne $original) {
                [System.IO.File]::WriteAllText($file, $content, $utf8NoBom)
                Write-Host "✏ $file"
            }
        }
    }
}

Normalize-Files $adminPaths $adminPrefix
Normalize-Files $operatorPaths $operatorPrefix

Write-Host "`n✅ UTF-8 OK. Кнопки нормализованы."
