# bot/keyboards/client/profile.py
from bot.constants.callbacks_client import ClientCartOpen
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def client_profile_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📦 Мои заказы",
                callback_data=ClientCartOpen().pack(),
            ),
        ],
        [
            InlineKeyboardButton(
                text="⬅️ В корзину",
                callback_data=().pack(),
            ),
        ],
    ])

