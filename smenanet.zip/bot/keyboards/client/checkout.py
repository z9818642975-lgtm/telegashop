# bot/keyboards/client/checkout.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.constants.callbacks_client import (
    ClientDeliveryPickup,
    ClientDeliveryCourier,
    ClientCartOpen,
)


def client_checkout_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="🚚 Курьер",
                callback_data=ClientDeliveryCourier().pack(),
            ),
            InlineKeyboardButton(
                text="📦 Самовывоз",
                callback_data=ClientDeliveryPickup().pack(),
            ),
        ],
        [
            InlineKeyboardButton(
                text="⬅️ В корзину",
                callback_data=ClientCartOpen().pack(),
            )
        ],
    ])
