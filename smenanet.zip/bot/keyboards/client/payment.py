# bot/keyboards/client/payment.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks_client import (
    ClientPayBank,
    ClientPaySBP,
    ClientPaymentDone,
    ClientPaymentCancel,
)


# =====================================================
# 1. ВЫБОР СПОСОБА ОПЛАТЫ (БАНК / СБП)
# =====================================================

def client_payment_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🏦 Сбер",
                    callback_data=ClientPayBank(bank_id=1).pack(),
                ),
                InlineKeyboardButton(
                    text="🏦 Т-Банк",
                    callback_data=ClientPayBank(bank_id=2).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🏦 Альфа",
                    callback_data=ClientPayBank(bank_id=3).pack(),
                ),
                InlineKeyboardButton(
                    text="📱 СБП",
                    callback_data=ClientPaySBP().pack(),
                ),
            ],
        ]
    )


# =====================================================
# 2. ПОДТВЕРЖДЕНИЕ ОПЛАТЫ (ПОСЛЕ ОТПРАВКИ ЧЕКА)
# =====================================================

def client_payment_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Я оплатил",
                    callback_data=ClientPaymentDone().pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="❌ Отмена",
                    callback_data=ClientPaymentCancel().pack(),
                ),
            ],
        ]
    )
