# bot/keyboards/client/delivery.py
from bot.constants.callbacks_client import (
    ClientDeliveryPickup,
    ClientDeliveryCourier,
)
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def client_delivery_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📍 Самовывоз",
                    callback_data=ClientDeliveryPickup().pack(),
                )
            ],
            [
                InlineKeyboardButton(
                    text="🚚 Курьер",
                    callback_data=ClientDeliveryCourier().pack(),
                )
            ],
            [
                InlineKeyboardButton(
                    text="⬅️ В корзину",
                    callback_data=().pack(),
                )
            ],
        ]
    )

