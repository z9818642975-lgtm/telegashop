# bot/keyboards/operator/items.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks_admin import (
    AdminWarehouseProductsCB,
    AdminWarehouseMoveCB,
    AdminWarehouseDeactivateCB,
    AdminWarehousesListCB,
)


def warehouse_actions_kb(warehouse_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="О 📦 Товары на складе",
                    callback_data=AdminWarehouseProductsCB(
                        warehouse_id=warehouse_id
                    ).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="О 🔁 Переместить товары",
                    callback_data=AdminWarehouseMoveCB(
                        warehouse_id=warehouse_id
                    ).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="О 📦 Архивировать склад",
                    callback_data=AdminWarehouseDeactivateCB(
                        warehouse_id=warehouse_id
                    ).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="О ⬅️ К складам",
                    callback_data=AdminWarehousesListCB().pack(),
                ),
            ],
        ]
    )
