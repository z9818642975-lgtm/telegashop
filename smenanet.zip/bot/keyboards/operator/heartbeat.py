# bot/keyboards/operator/heartbeat.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def iam_here_kb(shift_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="О 🟢 Я на месте",
                    callback_data=OperatorHeartbeatCB(shift_id=shift_id).pack(),
                )
            ]
        ]
    )

