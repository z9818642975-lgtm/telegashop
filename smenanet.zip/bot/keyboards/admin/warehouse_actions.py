# bot/keyboards/admin/warehouse_actions.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks_admin import (
    AdminWarehouseProductsCB,
    AdminWarehouseMoveCB,
    AdminWarehouseDeactivateCB,
    AdminWarehousesListCB,
)


def warehouse_actions_kb(warehouse_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="А 📦 Товары на складе",
                    callback_data=AdminWarehouseProductsCB(
                        warehouse_id=warehouse_id
                    ).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="А 🔁 Переместить товары",
                    callback_data=AdminWarehouseMoveCB(
                        warehouse_id=warehouse_id
                    ).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="А 📦 Архивировать склад",
                    callback_data=AdminWarehouseDeactivateCB(
                        warehouse_id=warehouse_id
                    ).pack(),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="А ⬅️ К складам",
                    callback_data=AdminWarehousesListCB().pack(),
                ),
            ],
        ]
    )
