from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.constants.callbacks import CB


def cart_inline_kb(items):
    buttons = []

    for item in items:
        buttons.append([
            InlineKeyboardButton(
                text=f"❌ {item.product.title}",
                callback_data=f"{CB.CART_REMOVE}:{item.id}",
            )
        ])

    buttons.append([
        InlineKeyboardButton(text="🧹 Очистить", callback_data=CB.CART_CLEAR),
        InlineKeyboardButton(text="💳 Оформить", callback_data=CB.CART_CHECKOUT),
    ])

    return InlineKeyboardMarkup(inline_keyboard=buttons)
