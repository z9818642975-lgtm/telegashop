from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks import CB


def quantity_kb(product_id: int) -> InlineKeyboardMarkup:
    """
    Клавиатура выбора количества.
    ❌ Без кнопки «Назад»
    """
    buttons = [
        InlineKeyboardButton(
            text=str(i),
            callback_data=CB.QTY.format(id=product_id, qty=i),
        )
        for i in range(1, 10)
    ]

    return InlineKeyboardMarkup(
        inline_keyboard=[buttons]
    )
