from __future__ import annotations

from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.orders_dao import OrdersDAO
from bot.dao.products_dao import ProductsDAO
from bot.routers.client.catalog import render_catalog

router = Router(name="client_quantity")


@router.callback_query(F.data.startswith("qty:"))
async def select_quantity(cb: CallbackQuery, session: AsyncSession, user):
    """
    qty:{product_id}:{qty}
    """
    try:
        _, product_id, qty = cb.data.split(":")
        product_id = int(product_id)
        qty = int(qty)
    except ValueError:
        await cb.answer("Ошибка выбора количества", show_alert=True)
        return

    if qty <= 0:
        await cb.answer("Некорректное количество", show_alert=True)
        return

    product = await ProductsDAO(session).get_by_id(product_id)
    if not product:
        await cb.answer("Товар не найден", show_alert=True)
        return

    orders = OrdersDAO(session)
    order = await orders.get_or_create_cart(user.id)

    await orders.add_item(
        order=order,
        product_id=product_id,
        qty=qty,
    )

    await session.commit()
    await cb.answer("Добавлено в корзину")

    await render_catalog(cb, session)

