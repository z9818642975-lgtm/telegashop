from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.users_dao import UsersDAO
from bot.models.enums import UserRole
from bot.config import settings


async def bootstrap_users(session: AsyncSession):
    dao = UsersDAO(session)

    # ADMIN
    for admin_id in settings.ADMINS:
        await dao.upsert(int(admin_id), UserRole.ADMIN)

    # OPERATOR
    if settings.OPERATOR_ID:
        await dao.upsert(int(settings.OPERATOR_ID), UserRole.OPERATOR)
