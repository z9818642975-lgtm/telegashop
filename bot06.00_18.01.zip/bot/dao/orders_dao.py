# bot/dao/orders_dao.py

from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models.order import Order, OrderStatus
from bot.models.order_item import OrderItem
from bot.dao.products_dao import ProductsDAO


class OrdersDAO:
    def __init__(self, session: AsyncSession):
        self.session = session

    # =========================
    # CART
    # =========================

    async def get_cart(self, client_tg_id: int) -> Order | None:
        res = await self.session.execute(
            select(Order).where(
                Order.client_id == client_tg_id,
                Order.status == OrderStatus.CART,
            )
        )
        return res.scalar_one_or_none()

    async def get_or_create_cart(self, client_tg_id: int) -> Order:
        order = await self.get_cart(client_tg_id)
        if order:
            return order

        order = Order(
            client_id=client_tg_id,
            status=OrderStatus.CART,
        )
        self.session.add(order)
        await self.session.flush()
        return order

    # =========================
    # ITEMS
    # =========================

    async def add_item(self, order: Order, product_id: int, qty: int):
        res = await self.session.execute(
            select(OrderItem).where(
                OrderItem.order_id == order.id,
                OrderItem.product_id == product_id,
            )
        )
        item = res.scalar_one_or_none()

        if item:
            item.qty += qty
            await self.session.flush()
            return

        product = await ProductsDAO(self.session).get_by_id(product_id)
        if not product:
            raise ValueError("Product not found")

        self.session.add(
            OrderItem(
                order_id=order.id,
                product_id=product_id,
                qty=qty,
                price=product.base_price,
            )
        )
        await self.session.flush()

    async def clear_cart(self, client_tg_id: int):
        order = await self.get_cart(client_tg_id)
        if not order:
            return

        await self.session.execute(
            delete(OrderItem).where(OrderItem.order_id == order.id)
        )
        await self.session.flush()

