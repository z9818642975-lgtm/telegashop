from __future__ import annotations

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models.user import User
from bot.models.enums import UserRole


class UsersDAO:
    def __init__(self, session: AsyncSession):
        self.session = session

    # =========================
    # GET
    # =========================

    async def get_by_tg_id(self, tg_id: int) -> User | None:
        res = await self.session.execute(
            select(User).where(User.tg_id == tg_id)
        )
        return res.scalar_one_or_none()

    async def list_operators(self) -> list[User]:
        res = await self.session.execute(
            select(User).where(User.role == UserRole.OPERATOR)
        )
        return res.scalars().all()

    # =========================
    # CREATE
    # =========================

    async def create(
        self,
        *,
        tg_id: int,
        role: UserRole,
        is_active: bool = True,
    ) -> User:
        user = User(
            tg_id=tg_id,
            role=role,
            is_active=is_active,
        )
        self.session.add(user)
        await self.session.flush()
        return user

    # =========================
    # UPSERT (ДЛЯ BOOTSTRAP)
    # =========================

    async def upsert(self, tg_id: int, role: UserRole) -> User:
        user = await self.get_by_tg_id(tg_id)
        if user:
            if user.role != role:
                user.role = role
                await self.session.flush()
            return user

        return await self.create(
            tg_id=tg_id,
            role=role,
            is_active=True,
        )

    # =========================
    # GET OR CREATE (RUNTIME)
    # =========================

    async def get_or_create_by_tg_id(
        self,
        *,
        tg_id: int,
        role: UserRole,
    ) -> User:
        user = await self.get_by_tg_id(tg_id)
        if user:
            return user

        return await self.create(
            tg_id=tg_id,
            role=role,
            is_active=True,
        )
