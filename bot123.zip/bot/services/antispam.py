import time

_last_message = {}

class AntiSpamService:
    @staticmethod
    def check(user_id: int, seconds: int = 10) -> bool:
        now = time.time()
        last = _last_message.get(user_id, 0)
        if now - last < seconds:
            return False
        _last_message[user_id] = now
        return True
