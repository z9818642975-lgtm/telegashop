# bot/keyboards/operator/operator_order.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks import CB


def operator_order_kb(order_id: int) -> InlineKeyboardMarkup:
    """
    Р С›РЎРѓР Р…Р С•Р Р†Р Р…Р В°РЎРЏ Р С”Р В»Р В°Р Р†Р С‘Р В°РЎвЂљРЎС“РЎР‚Р В° Р С•Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚Р В° Р Т‘Р В»РЎРЏ Р В·Р В°Р С”Р В°Р В·Р В°
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="РІСљвЂ¦ Р СџРЎР‚Р С‘Р Р…РЎРЏРЎвЂљРЎРЉ",
                    callback_data=CB.OP_CHECK_ACCEPT.format(id=order_id),
                ),
            ],
            [
                InlineKeyboardButton(
                    text="СЂСџРЏРѓ Р вЂ”Р В°Р Р†Р ВµРЎР‚РЎв‚¬Р С‘РЎвЂљРЎРЉ",
                    callback_data=CB.OP_READY.format(id=order_id),
                ),
                InlineKeyboardButton(
                    text="СЂСџвЂќв„ў Р СњР В°Р В·Р В°Р Т‘",
                    callback_data="op:orders",
                ),
            ],
        ]
    )


def ready_kb(order_id: int) -> InlineKeyboardMarkup:
    """
    Р С™Р Р…Р С•Р С—Р С”Р В° Р’В«Р вЂ”Р В°Р С”Р В°Р В· Р С–Р С•РЎвЂљР С•Р Р†Р’В»
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџвЂњВ¦ Р вЂ”Р В°Р С”Р В°Р В· Р С–Р С•РЎвЂљР С•Р Р†",
                    callback_data=CB.OP_READY.format(id=order_id),
                )
            ]
        ]
    )


def sent_kb(order_id: int) -> InlineKeyboardMarkup:
    """
    Р С™Р Р…Р С•Р С—Р С”Р В° Р’В«Р вЂ”Р В°Р С”Р В°Р В· Р С—Р ВµРЎР‚Р ВµР Т‘Р В°Р Р… / Р Р†РЎвЂ№Р Т‘Р В°Р Р…Р’В»
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџС™С™ Р СџР ВµРЎР‚Р ВµР Т‘Р В°Р Р… Р С”Р В»Р С‘Р ВµР Р…РЎвЂљРЎС“",
                    callback_data=CB.OP_SENT.format(id=order_id),
                )
            ]
        ]
    )
