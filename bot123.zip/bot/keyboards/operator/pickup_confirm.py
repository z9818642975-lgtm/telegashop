from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def pickup_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="РІСљвЂ¦ Р СџР С•Р Т‘РЎвЂљР Р†Р ВµРЎР‚Р Т‘Р С‘РЎвЂљРЎРЉ",
                    callback_data="op:pickup:confirm",
                ),
                InlineKeyboardButton(
                    text="РІСњРЉ Р С›РЎвЂљР СР ВµР Р…Р С‘РЎвЂљРЎРЉ",
                    callback_data="op:pickup:cancel",
                ),
            ]
        ]
    )
