from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_panel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџРЏВ¬ Р РЋР С”Р В»Р В°Р Т‘РЎвЂ№",
                    callback_data="admin:warehouses",
                ),
                InlineKeyboardButton(
                    text="СЂСџвЂњВ¦ Р СћР С•Р Р†Р В°РЎР‚РЎвЂ№",
                    callback_data="admin:products",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="СЂСџвЂВ· Р С›Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚РЎвЂ№",
                    callback_data="admin:operators",
                ),
                InlineKeyboardButton(
                    text="СЂСџРЏВ¦ Р вЂР В°Р Р…Р С”Р С‘",
                    callback_data="admin:banks",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="СЂСџвЂњР‰ Р РЋРЎвЂљР В°РЎвЂљР С‘РЎРѓРЎвЂљР С‘Р С”Р В°",
                    callback_data="admin:stats",
                ),
            ],
        ]
    )
