from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.models.warehouse import Warehouse


def warehouses_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="РІС›вЂў Р РЋР С•Р В·Р Т‘Р В°РЎвЂљРЎРЉ РЎРѓР С”Р В»Р В°Р Т‘",
                    callback_data="admin:warehouse:create",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="РІВ¬вЂ¦РїС‘РЏ Р СњР В°Р В·Р В°Р Т‘",
                    callback_data="admin:panel",
                ),
            ],
        ]
    )


def warehouses_kb(items: list[Warehouse]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"СЂСџРЏВ¬ {wh.title}",
                    callback_data=f"admin:wh:{wh.id}",
                )
            ]
            for wh in items
        ]
    )
