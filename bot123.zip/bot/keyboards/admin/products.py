from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.models.product import Product


def products_kb(products: list[Product]) -> InlineKeyboardMarkup:
    keyboard = []

    for p in products:
        status = "СЂСџСџСћ" if p.is_active else "РІС™В«РїС‘РЏ"
        keyboard.append(
            [
                InlineKeyboardButton(
                    text=f"{status} {p.title} ({p.base_price} РІвЂљР…)",
                    callback_data=f"admin:product:card:{p.id}",
                )
            ]
        )

    keyboard.append(
        [
            InlineKeyboardButton(
                text="РІС›вЂў Р вЂќР С•Р В±Р В°Р Р†Р С‘РЎвЂљРЎРЉ РЎвЂљР С•Р Р†Р В°РЎР‚",
                callback_data="admin:product:create",
            )
        ]
    )
    keyboard.append(
        [
            InlineKeyboardButton(
                text="РІВ¬вЂ¦РїС‘РЏ Р СњР В°Р В·Р В°Р Т‘",
                callback_data="admin:panel",
            )
        ]
    )

    return InlineKeyboardMarkup(inline_keyboard=keyboard)
