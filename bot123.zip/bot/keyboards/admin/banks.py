from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def banks_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџвЂњвЂћ Р РЋР С—Р С‘РЎРѓР С•Р С” Р В±Р В°Р Р…Р С”Р С•Р Р†",
                    callback_data="admin:bank:list",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="РІС›вЂў Р вЂќР С•Р В±Р В°Р Р†Р С‘РЎвЂљРЎРЉ Р В±Р В°Р Р…Р С”",
                    callback_data="admin:bank:create",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="РІВ¬вЂ¦РїС‘РЏ Р СњР В°Р В·Р В°Р Т‘",
                    callback_data="admin:panel",
                ),
            ],
        ]
    )
