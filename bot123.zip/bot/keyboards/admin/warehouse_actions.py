# bot/keyboards/warehouse_actions.py

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def warehouse_actions_kb(warehouse_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџвЂњВ¦ Р СћР С•Р Р†Р В°РЎР‚РЎвЂ№ Р Р…Р В° РЎРѓР С”Р В»Р В°Р Т‘Р Вµ",
                    callback_data=f"admin:wh:{warehouse_id}:products",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="СЂСџвЂќРѓ Р СџР ВµРЎР‚Р ВµР СР ВµРЎРѓРЎвЂљР С‘РЎвЂљРЎРЉ РЎвЂљР С•Р Р†Р В°РЎР‚РЎвЂ№",
                    callback_data=f"admin:wh:{warehouse_id}:move",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="РІСњРЉ Р вЂќР ВµР В°Р С”РЎвЂљР С‘Р Р†Р С‘РЎР‚Р С•Р Р†Р В°РЎвЂљРЎРЉ РЎРѓР С”Р В»Р В°Р Т‘",
                    callback_data=f"admin:wh:{warehouse_id}:disable",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="РІВ¬вЂ¦РїС‘РЏ Р СњР В°Р В·Р В°Р Т‘",
                    callback_data="admin:warehouses",
                ),
            ],
        ]
    )
