from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks import CB


def checkout_kb() -> InlineKeyboardMarkup:
    """
    Р СџР ВµРЎР‚Р Р†РЎвЂ№Р в„– РЎРЊР С”РЎР‚Р В°Р Р… РЎвЂЎР ВµР С”Р В°РЎС“РЎвЂљР В° (Р С‘Р В· Р С”Р С•РЎР‚Р В·Р С‘Р Р…РЎвЂ№)
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџС™С™ Р вЂ™РЎвЂ№Р В±РЎР‚Р В°РЎвЂљРЎРЉ РЎРѓР С—Р С•РЎРѓР С•Р В± Р Т‘Р С•РЎРѓРЎвЂљР В°Р Р†Р С”Р С‘",
                    callback_data=CB.CART_CHECKOUT,
                )
            ],
            [
                InlineKeyboardButton(
                    text="РІВ¬вЂ¦РїС‘РЏ Р вЂ™ Р С”Р С•РЎР‚Р В·Р С‘Р Р…РЎС“",
                    callback_data=CB.CART_OPEN,
                )
            ],
        ]
    )


def delivery_type_kb() -> InlineKeyboardMarkup:
    """
    Р вЂ™РЎвЂ№Р В±Р С•РЎР‚ РЎвЂљР С‘Р С—Р В° Р Т‘Р С•РЎРѓРЎвЂљР В°Р Р†Р С”Р С‘
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="СЂСџвЂњРЊ Р РЋР В°Р СР С•Р Р†РЎвЂ№Р Р†Р С•Р В·",
                    callback_data=CB.DELIVERY_PICKUP,
                )
            ],
            [
                InlineKeyboardButton(
                    text="СЂСџС™С™ Р С™РЎС“РЎР‚РЎРЉР ВµРЎР‚",
                    callback_data=CB.DELIVERY_COURIER,
                )
            ],
            [
                InlineKeyboardButton(
                    text="РІВ¬вЂ¦РїС‘РЏ Р вЂ™ Р С”Р С•РЎР‚Р В·Р С‘Р Р…РЎС“",
                    callback_data=CB.CART_OPEN,
                )
            ],
        ]
    )
