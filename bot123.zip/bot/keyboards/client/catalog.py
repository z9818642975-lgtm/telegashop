from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.models.product import Product
from bot.constants.callbacks import CB


def catalog_kb(products: list[Product]) -> InlineKeyboardMarkup:
    keyboard: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []

    for product in products:
        row.append(
            InlineKeyboardButton(
                text=f"{product.title} РІР‚вЂќ {product.base_price} РІвЂљР…",
                callback_data=CB.PRODUCT.format(id=product.id),
            )
        )

        if len(row) == 2:
            keyboard.append(row)
            row = []

    if row:
        keyboard.append(row)

    keyboard.append(
        [
            InlineKeyboardButton(text="СЂСџВ§С” Р С™Р С•РЎР‚Р В·Р С‘Р Р…Р В°", callback_data=CB.CART_OPEN),
            InlineKeyboardButton(text="РІСљвЂ¦ Р С›РЎвЂћР С•РЎР‚Р СР С‘РЎвЂљРЎРЉ Р В·Р В°Р С”Р В°Р В·", callback_data=CB.CART_CHECKOUT),
        ]
    )

    return InlineKeyboardMarkup(inline_keyboard=keyboard)
