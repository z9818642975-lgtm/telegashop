from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.constants.callbacks import CB
from bot.models.order_item import OrderItem


def cart_inline_kb(items: list[OrderItem]) -> InlineKeyboardMarkup:
    keyboard: list[list[InlineKeyboardButton]] = []

    for item in items:
        keyboard.append(
            [
                InlineKeyboardButton(
                    text=f"РІСњРЉ Р Р€Р В±РЎР‚Р В°РЎвЂљРЎРЉ {item.product.title}",
                    callback_data=f"{CB.CART_REMOVE}:{item.id}",
                )
            ]
        )

    keyboard.append(
        [
            InlineKeyboardButton(
                text="СЂСџВ§в„– Р С›РЎвЂЎР С‘РЎРѓРЎвЂљР С‘РЎвЂљРЎРЉ Р С”Р С•РЎР‚Р В·Р С‘Р Р…РЎС“",
                callback_data=CB.CART_CLEAR,
            )
        ]
    )

    keyboard.append(
        [
            InlineKeyboardButton(
                text="РІВ¬вЂ¦РїС‘РЏ Р вЂ™ Р С”Р В°РЎвЂљР В°Р В»Р С•Р С–",
                callback_data=CB.BACK_CATALOG,
            ),
            InlineKeyboardButton(
                text="РІСљвЂ¦ Р С›РЎвЂћР С•РЎР‚Р СР С‘РЎвЂљРЎРЉ Р В·Р В°Р С”Р В°Р В·",
                callback_data=CB.CART_CHECKOUT,
            ),
        ]
    )

    return InlineKeyboardMarkup(inline_keyboard=keyboard)
