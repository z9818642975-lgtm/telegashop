# bot/keyboards/client/main.py
from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
)


def client_main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="СЂСџвЂњВ¦ Р С™Р В°РЎвЂљР В°Р В»Р С•Р С–"),
                KeyboardButton(text="СЂСџВ§С” Р С™Р С•РЎР‚Р В·Р С‘Р Р…Р В°"),
            ],
            [
                KeyboardButton(text="СЂСџвЂВ¤ Р СџРЎР‚Р С•РЎвЂћР С‘Р В»РЎРЉ"),
                KeyboardButton(text="РІСњвЂњ FAQ"),
            ],
            [
                KeyboardButton(text="СЂСџвЂ™В¬ Р РЋР Р†РЎРЏР В·РЎРЉ РЎРѓ Р С•Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚Р С•Р С"),
            ],
        ],
        resize_keyboard=True,
        selective=True,
    )
