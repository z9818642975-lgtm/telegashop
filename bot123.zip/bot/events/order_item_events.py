# bot/events/order_item_events.py
from dataclasses import dataclass

# bot/events/order_item_events.py
from dataclasses import dataclass


from bot.models.enums import OrderItemStatus








@dataclass(slots=True)


class OrderItemStatusChanged:


    user_id: int


    order_item_id: int


    product_title: str


    status: OrderItemStatus




