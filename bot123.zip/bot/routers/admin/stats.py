# bot/routers/admin/stats.py
# ============================================================

# bot/routers/admin/stats.py
# ============================================================


# bot/routers/admin/stats.py


# ============================================================





from aiogram import Router, F


from aiogram.types import CallbackQuery


from sqlalchemy.ext.asyncio import AsyncSession





from bot.dao.statistics import StatisticsDAO





router = Router(name="admin_stats")








# ------------------------------------------------------------


# Р РЋР вЂ™Р С›Р вЂќР С™Р С’


# ------------------------------------------------------------





@router.callback_query(F.data == "admin:stats:summary")


async def admin_stats_summary(


    callback: CallbackQuery,


    session: AsyncSession | None = None,


) -> None:


    dao = StatisticsDAO(session)


    data = await dao.today_summary()





    await callback.message.edit_text(


        "СЂСџвЂњР‰ <b>Р РЋРЎвЂљР В°РЎвЂљР С‘РЎРѓРЎвЂљР С‘Р С”Р В° Р В·Р В° РЎРѓР ВµР С–Р С•Р Т‘Р Р…РЎРЏ</b>\n\n"


        f"СЂСџвЂњВ¦ Р вЂ”Р В°Р С”Р В°Р В·Р С•Р Р†: {data['orders_total']}\n"


        f"РІСљвЂ¦ Р С›Р С—Р В»Р В°РЎвЂЎР ВµР Р…Р С•: {data['orders_paid']}\n"


        f"СЂСџвЂ™В° Р С›Р В±Р С•РЎР‚Р С•РЎвЂљ: {data['revenue']} РІвЂљР…\n"


        f"СЂСџВ§С• Р РЋРЎР‚Р ВµР Т‘Р Р…Р С‘Р в„– РЎвЂЎР ВµР С”: {data['avg_check']} РІвЂљР…\n\n"


        f"СЂСџвЂВ· Р С›Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚Р С•Р Р† Р Р†РЎРѓР ВµР С–Р С•: {data['operators_total']}\n"


        f"СЂСџСџСћ Р С’Р С”РЎвЂљР С‘Р Р†Р Р…РЎвЂ№РЎвЂ¦ РЎРѓР СР ВµР Р…: {data['active_shifts']}\n\n"


        f"СЂСџвЂ™С‘ Р СњР В°РЎвЂЎР С‘РЎРѓР В»Р ВµР Р…Р С• Р В·Р В°РЎР‚Р С—Р В»Р В°РЎвЂљ: {data['salary_today']} РІвЂљР…",


        parse_mode="HTML",


    )


    await callback.answer()








# ------------------------------------------------------------


# Р вЂ”Р С’Р С™Р С’Р вЂ”Р В«: Р РЋР СћР С’Р СћР Р€Р РЋР В« + Р СћР С’Р в„ўР СљР ВР СњР вЂњР В


# ------------------------------------------------------------





@router.callback_query(F.data == "admin:stats:orders")


async def admin_stats_orders(


    callback: CallbackQuery,


    session: AsyncSession | None = None,


) -> None:


    dao = StatisticsDAO(session)





    statuses = await dao.orders_by_status_today()


    timings = await dao.order_timings_today()





    text = "СЂСџвЂњВ¦ <b>Р вЂ”Р В°Р С”Р В°Р В·РЎвЂ№ Р В·Р В° РЎРѓР ВµР С–Р С•Р Т‘Р Р…РЎРЏ</b>\n\n"





    for status, count in statuses.items():


        text += f"{status}: {count}\n"





    text += (


        f"\nРІРЏВ± <b>Р РЋРЎР‚Р ВµР Т‘Р Р…Р ВµР Вµ Р Р†РЎР‚Р ВµР СРЎРЏ</b>\n"


        f"РІвЂ вЂ™ Р Т‘Р С• Р С•Р С—Р В»Р В°РЎвЂљРЎвЂ№: {timings['to_paid_min']} Р СР С‘Р Р…\n"


        f"РІвЂ вЂ™ Р Т‘Р С• Р С•РЎвЂљР С—РЎР‚Р В°Р Р†Р С”Р С‘: {timings['to_sent_min']} Р СР С‘Р Р…"


    )





    await callback.message.edit_text(text, parse_mode="HTML")


    await callback.answer()








# ------------------------------------------------------------


# Р С›Р СџР вЂўР В Р С’Р СћР С›Р В Р В«: SLA


# ------------------------------------------------------------





@router.callback_query(F.data == "admin:stats:operators")


async def admin_stats_operators(


    callback: CallbackQuery,


    session: AsyncSession | None = None,


) -> None:


    dao = StatisticsDAO(session)


    data = await dao.operators_sla_today()





    await callback.message.edit_text(


        "СЂСџвЂВ· <b>Р С›Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚РЎвЂ№ Р В·Р В° РЎРѓР ВµР С–Р С•Р Т‘Р Р…РЎРЏ</b>\n\n"


        f"СЂСџСџСћ Р РЋР СР ВµР Р… Р С•РЎвЂљР С”РЎР‚РЎвЂ№РЎвЂљР С•: {data['shifts_total']}\n"


        f"РІСљвЂ¦ Р РЋР СР ВµР Р… Р В·Р В°Р С”РЎР‚РЎвЂ№РЎвЂљР С•: {data['shifts_closed']}\n"


        f"СЂСџС™В« Р вЂ™РЎвЂ№Р С”Р С‘Р Р…РЎС“РЎвЂљР С• РЎРѓР С• РЎРѓР СР ВµР Р…РЎвЂ№: {data['kicked']}",


        parse_mode="HTML",


    )


    await callback.answer()








# ------------------------------------------------------------


# Р вЂ™Р В«Р В Р Р€Р В§Р С™Р С’: Р вЂР С’Р СњР С™ vs Р РЋР вЂР Сџ


# ------------------------------------------------------------





@router.callback_query(F.data == "admin:stats:revenue")


async def admin_stats_revenue(


    callback: CallbackQuery,


    session: AsyncSession | None = None,


) -> None:


    dao = StatisticsDAO(session)


    data = await dao.revenue_by_method_today()





    text = "СЂСџвЂ™В° <b>Р вЂ™РЎвЂ№РЎР‚РЎС“РЎвЂЎР С”Р В° Р В·Р В° РЎРѓР ВµР С–Р С•Р Т‘Р Р…РЎРЏ</b>\n\n"


    for method, amount in data.items():


        text += f"{method}: {amount} РІвЂљР…\n"





    await callback.message.edit_text(text, parse_mode="HTML")


    await callback.answer()





