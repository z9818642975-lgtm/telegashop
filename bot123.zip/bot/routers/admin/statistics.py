from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.filters.role import RoleFilter
from bot.dao.statistics_dao import StatisticsDAO

router = Router(name="admin_statistics")

@router.callback_query(RoleFilter("admin"), F.data == "admin:stats:week")
async def stats_week(cb, *, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    d = await dao.period_summary(days=7)
    await cb.message.edit_text(
        "СЂСџвЂњР‰ <b>Р СњР ВµР Т‘Р ВµР В»РЎРЏ</b>\n\n"
        f"СЂСџвЂњВ¦ {d['orders_total']}\n"
        f"РІСљвЂ¦ {d['orders_paid']}\n"
        f"СЂСџвЂ™В° {d['revenue']} РІвЂљР…\n"
        f"СЂСџВ§С• {d['avg_check']} РІвЂљР…",
        parse_mode="HTML",
    )
    await cb.answer()

@router.callback_query(RoleFilter("admin"), F.data == "admin:stats:month")
async def stats_month(cb, *, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    d = await dao.period_summary(days=30)
    await cb.message.edit_text(
        "СЂСџвЂњР‰ <b>Р СљР ВµРЎРѓРЎРЏРЎвЂ </b>\n\n"
        f"СЂСџвЂњВ¦ {d['orders_total']}\n"
        f"РІСљвЂ¦ {d['orders_paid']}\n"
        f"СЂСџвЂ™В° {d['revenue']} РІвЂљР…\n"
        f"СЂСџВ§С• {d['avg_check']} РІвЂљР…",
        parse_mode="HTML",
    )
    await cb.answer()


