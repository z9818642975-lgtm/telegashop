# bot/routers/admin/__init__.py

from aiogram import Router

from .panel import router as panel_router
from .products import router as products_router
from .operators import router as operators_router
from .reports import router as reports_router

router = Router(name="admin")

router.include_router(panel_router)
router.include_router(products_router)
router.include_router(operators_router)
router.include_router(reports_router)
