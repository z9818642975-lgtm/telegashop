from __future__ import annotations

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.filters.role import RoleFilter
from bot.constants.callbacks import CB

from bot.dao.users_dao import UsersDAO
from bot.dao.products_dao import ProductsDAO
from bot.dao.warehouses_dao import WarehousesDAO
from bot.dao.orders_dao import OrdersDAO
from bot.dao.payment_dao import PaymentDAO
from bot.dao.statistics_dao import StatisticsDAO

from bot.models.enums import OrderStatus

from bot.keyboards.admin.panel import admin_panel_kb
from bot.keyboards.admin.products import products_kb
from bot.keyboards.admin.warehouses import warehouses_kb
from bot.keyboards.admin.operators import operators_kb
from bot.keyboards.admin.payments import banks_kb
from bot.keyboards.admin.orders import admin_orders_kb

router = Router(name="admin")

# ============================================================
# ENTRY
# ============================================================

@router.message(RoleFilter("admin"), F.text == "СЂСџвЂвЂ Р С’Р Т‘Р СР С‘Р Р…")
async def admin_panel(message: Message):
    await message.answer(
        "СЂСџвЂвЂ Р С’Р Т‘Р СР С‘Р Р…-Р С—Р В°Р Р…Р ВµР В»РЎРЉ",
        reply_markup=admin_panel_kb(),
    )

# ============================================================
# PRODUCTS
# ============================================================

@router.callback_query(RoleFilter("admin"), F.data == CB.ADMIN_PRODUCTS)
async def admin_products(call: CallbackQuery, session: AsyncSession | None = None):
    products = await ProductsDAO.list_all(session)

    await call.message.edit_text(
        "СЂСџвЂњВ¦ Р СћР С•Р Р†Р В°РЎР‚РЎвЂ№",
        reply_markup=products_kb(products),
    )
    await call.answer()

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:product:toggle"))
async def admin_product_toggle(call: CallbackQuery, session: AsyncSession | None = None):
    product_id = int(call.data.split(":")[-1])
    await ProductsDAO.toggle_active(session, product_id)
    await session.commit()
    await call.answer("OK")

# ============================================================
# WAREHOUSES
# ============================================================

@router.callback_query(RoleFilter("admin"), F.data == CB.ADMIN_WAREHOUSES)
async def admin_warehouses(call: CallbackQuery, session: AsyncSession | None = None):
    dao = WarehousesDAO(session)
    warehouses = await dao.list_all()
    await call.message.edit_text(
        "СЂСџРЏВ¬ Р РЋР С”Р В»Р В°Р Т‘РЎвЂ№",
        reply_markup=warehouses_kb(warehouses),
    )
    await call.answer()

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:warehouse:move"))
async def admin_warehouse_move(call: CallbackQuery, session: AsyncSession | None = None):
    _, _, from_id, to_id, product_id, qty = call.data.split(":")
    dao = WarehousesDAO(session)
    await dao.move(
        from_warehouse_id=int(from_id),
        to_warehouse_id=int(to_id),
        product_id=int(product_id),
        quantity=int(qty),
    )
    await session.commit()
    await call.answer("Р СџР ВµРЎР‚Р ВµР СР ВµРЎвЂ°Р ВµР Р…Р С•")

# ============================================================
# OPERATORS
# ============================================================

@router.callback_query(RoleFilter("admin"), F.data == CB.ADMIN_OPERATORS)
async def admin_operators(call: CallbackQuery, session: AsyncSession | None = None):
    users = UsersDAO(session)
    operators = await users.list_operators()
    await call.message.edit_text(
        "СЂСџвЂВ· Р С›Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚РЎвЂ№",
        reply_markup=operators_kb(operators),
    )
    await call.answer()

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:operator:toggle"))
async def admin_operator_toggle(call: CallbackQuery, session: AsyncSession | None = None):
    operator_id = int(call.data.split(":")[-1])
    users = UsersDAO(session)
    await users.toggle_active(operator_id)
    await session.commit()
    await call.answer("OK")

# ============================================================
# BANKS / PAYMENTS
# ============================================================

@router.callback_query(RoleFilter("admin"), F.data == "admin:banks")
async def admin_banks(call: CallbackQuery, session: AsyncSession | None = None):
    dao = PaymentDAO(session)
    banks = await dao.list_requisites()
    await call.message.edit_text(
        "СЂСџвЂ™С– Р В Р ВµР С”Р Р†Р С‘Р В·Р С‘РЎвЂљРЎвЂ№",
        reply_markup=banks_kb(banks),
    )
    await call.answer()

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:bank:toggle"))
async def admin_bank_toggle(call: CallbackQuery, session: AsyncSession | None = None):
    bank_id = int(call.data.split(":")[-1])
    dao = PaymentDAO(session)
    await dao.toggle_bank(bank_id)
    await session.commit()
    await call.answer("OK")

# ============================================================
# ORDERS
# ============================================================

@router.callback_query(RoleFilter("admin"), F.data == "admin:orders")
async def admin_orders(call: CallbackQuery, session: AsyncSession | None = None):
    dao = OrdersDAO(session)
    orders = await dao.list_recent(limit=20)
    await call.message.edit_text(
        "СЂСџвЂњвЂ№ Р вЂ”Р В°Р С”Р В°Р В·РЎвЂ№",
        reply_markup=admin_orders_kb(orders),
    )
    await call.answer()

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:order:force"))
async def admin_force_order(call: CallbackQuery, session: AsyncSession | None = None):
    _, _, order_id, status = call.data.split(":")
    dao = OrdersDAO(session)
    await dao.force_status(
        order_id=int(order_id),
        status=OrderStatus(status),
    )
    await session.commit()
    await call.answer("Р РЋРЎвЂљР В°РЎвЂљРЎС“РЎРѓ Р С‘Р В·Р СР ВµР Р…РЎвЂР Р…")

# ============================================================
# PAYMENTS ACTIONS
# ============================================================

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:payment:approve"))
async def admin_payment_approve(call: CallbackQuery, session: AsyncSession | None = None):
    payment_id = int(call.data.split(":")[-1])
    payments = PaymentDAO(session)
    orders = OrdersDAO(session)

    payment = await payments.get(payment_id)
    await payments.approve(payment_id)
    await orders.mark_paid(payment.order_id)

    await session.commit()
    await call.answer("Р СџР В»Р В°РЎвЂљРЎвЂР В¶ Р С—Р С•Р Т‘РЎвЂљР Р†Р ВµРЎР‚Р В¶Р Т‘РЎвЂР Р…")

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:payment:reject"))
async def admin_payment_reject(call: CallbackQuery, session: AsyncSession | None = None):
    payment_id = int(call.data.split(":")[-1])
    payments = PaymentDAO(session)
    await payments.reject(payment_id, reason="Р С›РЎвЂљР С”Р В»Р С•Р Р…Р ВµР Р…Р С• Р В°Р Т‘Р СР С‘Р Р…Р С‘РЎРѓРЎвЂљРЎР‚Р В°РЎвЂљР С•РЎР‚Р С•Р С")
    await session.commit()
    await call.answer("Р С›РЎвЂљР С”Р В»Р С•Р Р…Р ВµР Р…Р С•")

# ============================================================
# STATISTICS
# ============================================================

@router.callback_query(F.data == "admin:stats:week")
async def stats_week(call: CallbackQuery, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    data = await dao.period_summary(days=7)
    await call.message.edit_text(
        "СЂСџвЂњР‰ <b>Р СњР ВµР Т‘Р ВµР В»РЎРЏ</b>\n\n"
        f"СЂСџвЂњВ¦ Р вЂ”Р В°Р С”Р В°Р В·Р С•Р Р†: {data['orders_total']}\n"
        f"РІСљвЂ¦ Р С›Р С—Р В»Р В°РЎвЂЎР ВµР Р…Р С•: {data['orders_paid']}\n"
        f"СЂСџвЂ™В° Р С›Р В±Р С•РЎР‚Р С•РЎвЂљ: {data['revenue']} РІвЂљР…\n"
        f"СЂСџВ§С• Р РЋРЎР‚Р ВµР Т‘Р Р…Р С‘Р в„– РЎвЂЎР ВµР С”: {data['avg_check']} РІвЂљР…",
        parse_mode="HTML",
    )
    await call.answer()

@router.callback_query(F.data == "admin:stats:month")
async def stats_month(call: CallbackQuery, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    data = await dao.period_summary(days=30)
    await call.message.edit_text(
        "СЂСџвЂњР‰ <b>Р СљР ВµРЎРѓРЎРЏРЎвЂ </b>\n\n"
        f"СЂСџвЂњВ¦ Р вЂ”Р В°Р С”Р В°Р В·Р С•Р Р†: {data['orders_total']}\n"
        f"РІСљвЂ¦ Р С›Р С—Р В»Р В°РЎвЂЎР ВµР Р…Р С•: {data['orders_paid']}\n"
        f"СЂСџвЂ™В° Р С›Р В±Р С•РЎР‚Р С•РЎвЂљ: {data['revenue']} РІвЂљР…\n"
        f"СЂСџВ§С• Р РЋРЎР‚Р ВµР Т‘Р Р…Р С‘Р в„– РЎвЂЎР ВµР С”: {data['avg_check']} РІвЂљР…",
        parse_mode="HTML",
    )
    await call.answer()

@router.callback_query(F.data == "admin:stats:per_operator")
async def stats_per_operator(call: CallbackQuery, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    rows = await dao.per_operator(days=30)

    text = "СЂСџвЂВ¤ <b>Р С›Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚РЎвЂ№ (30 Р Т‘Р Р…Р ВµР в„–)</b>\n\n"
    for r in rows:
        text += f"{r['name']}\n  СЂСџвЂњВ¦ {r['orders']} | СЂСџвЂ™В° {r['revenue']} РІвЂљР…\n"

    await call.message.edit_text(text, parse_mode="HTML")
    await call.answer()

@router.callback_query(F.data == "admin:stats:per_warehouse")
async def stats_per_warehouse(call: CallbackQuery, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    rows = await dao.per_warehouse(days=30)

    text = "СЂСџРЏВ¬ <b>Р РЋР С”Р В»Р В°Р Т‘РЎвЂ№ (30 Р Т‘Р Р…Р ВµР в„–)</b>\n\n"
    for r in rows:
        text += f"{r['title']}\n  СЂСџвЂњВ¦ {r['orders']} | СЂСџвЂ™В° {r['revenue']} РІвЂљР…\n"

    await call.message.edit_text(text, parse_mode="HTML")
    await call.answer()

@router.callback_query(F.data == "admin:stats:graph")
async def stats_graph(call: CallbackQuery, session: AsyncSession | None = None):
    dao = StatisticsDAO(session)
    data = await dao.revenue_timeseries(days=30)

    text = "СЂСџвЂњв‚¬ <b>Р вЂ™РЎвЂ№РЎР‚РЎС“РЎвЂЎР С”Р В° Р С—Р С• Р Т‘Р Р…РЎРЏР С (30 Р Т‘Р Р…Р ВµР в„–)</b>\n\n"
    for d in data:
        text += f"{d['date']} РІвЂ вЂ™ {d['revenue']} РІвЂљР…\n"

    await call.message.edit_text(text, parse_mode="HTML")
    await call.answer()

