# bot/routers/admin/warehouses_move.py

# bot/routers/admin/warehouses_move.py
# bot/routers/admin/warehouses_move.py


from __future__ import annotations





from aiogram import Router, F


from aiogram.types import CallbackQuery, Message


from aiogram.fsm.context import FSMContext


from sqlalchemy.ext.asyncio import AsyncSession





from bot.filters.role import RoleFilter


from bot.fsm.admin_move_fsm import AdminMoveFSM


from bot.dao.warehouses_dao import WarehousesDAO


from bot.dao.products_dao import ProductsDAO





router = Router(name="admin_warehouse_move")








# ============================================================


# СЂСџвЂќРѓ Р вЂ™Р В«Р вЂР С›Р В  Р ВР РЋР ТђР С›Р вЂќР СњР С›Р вЂњР С› Р РЋР С™Р вЂєР С’Р вЂќР С’


# ============================================================





@router.callback_query(RoleFilter("admin"), F.data == "admin:move:start")


async def move_start(call: CallbackQuery, state: FSMContext | None = None, session: AsyncSession | None = None):


    dao = WarehousesDAO(session)


    warehouses = await dao.get_all()





    await state.set_state(AdminMoveFSM.from_warehouse)





    text = "СЂСџвЂќРѓ <b>Р СџР ВµРЎР‚Р ВµР СР ВµРЎвЂ°Р ВµР Р…Р С‘Р Вµ РЎвЂљР С•Р Р†Р В°РЎР‚Р В°</b>\n\nР вЂ™РЎвЂ№Р В±Р ВµРЎР‚Р С‘РЎвЂљР Вµ РЎРѓР С”Р В»Р В°Р Т‘-Р С‘РЎРѓРЎвЂљР С•РЎвЂЎР Р…Р С‘Р С”:"


    kb = [


        [("СЂСџРЏВ¬ " + w.title, f"admin:move:from:{w.id}")]


        for w in warehouses


    ]





    await call.message.edit_text(text, reply_markup=dao.inline_kb(kb))








# ============================================================


# СЂСџРЏВ¬ FROM


# ============================================================





@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:move:from:"))


async def choose_from(


    call: CallbackQuery,


    state: FSMContext | None = None,


):


    from_id = int(call.data.split(":")[-1])


    await state.update_data(from_wh=from_id)


    await state.set_state(AdminMoveFSM.to_warehouse)





    await call.message.edit_text("РІС›РЋРїС‘РЏ Р вЂ™РЎвЂ№Р В±Р ВµРЎР‚Р С‘РЎвЂљР Вµ РЎРѓР С”Р В»Р В°Р Т‘-Р С—Р С•Р В»РЎС“РЎвЂЎР В°РЎвЂљР ВµР В»РЎРЉ:")








# ============================================================


# СЂСџРЏВ¬ TO


# ============================================================





@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:move:to:"))


async def choose_to(


    call: CallbackQuery,


    state: FSMContext | None = None,


):


    to_id = int(call.data.split(":")[-1])


    await state.update_data(to_wh=to_id)


    await state.set_state(AdminMoveFSM.product)





    await call.message.edit_text("СЂСџвЂњВ¦ Р вЂ™Р Р†Р ВµР Т‘Р С‘РЎвЂљР Вµ ID РЎвЂљР С•Р Р†Р В°РЎР‚Р В°:")








# ============================================================


# СЂСџвЂњВ¦ PRODUCT


# ============================================================





@router.message(RoleFilter("admin"), AdminMoveFSM.product)


async def enter_product(message, *, state: FSMContext | None = None,


):


    if not message.text.isdigit():


        await message.answer("РІСњРЉ Р вЂ™Р Р†Р ВµР Т‘Р С‘РЎвЂљР Вµ РЎвЂЎР С‘РЎРѓР В»Р С•Р Р†Р С•Р в„– ID РЎвЂљР С•Р Р†Р В°РЎР‚Р В°")


        return





    await state.update_data(product_id=int(message.text))


    await state.set_state(AdminMoveFSM.qty)





    await message.answer("СЂСџвЂќСћ Р вЂ™Р Р†Р ВµР Т‘Р С‘РЎвЂљР Вµ Р С”Р С•Р В»Р С‘РЎвЂЎР ВµРЎРѓРЎвЂљР Р†Р С•:")








# ============================================================


# СЂСџвЂќСћ QTY РІвЂ вЂ™ MOVE


# ============================================================





@router.message(RoleFilter("admin"), AdminMoveFSM.qty)


async def do_move(message, *, state: FSMContext | None = None,


    session: AsyncSession | None = None,


):


    if not message.text.isdigit():


        await message.answer("РІСњРЉ Р С™Р С•Р В»Р С‘РЎвЂЎР ВµРЎРѓРЎвЂљР Р†Р С• Р Т‘Р С•Р В»Р В¶Р Р…Р С• Р В±РЎвЂ№РЎвЂљРЎРЉ РЎвЂЎР С‘РЎРѓР В»Р С•Р С")


        return





    data = await state.get_data()





    qty = int(message.text)


    from_wh = data["from_wh"]


    to_wh = data["to_wh"]


    product_id = data["product_id"]





    wh_dao = WarehousesDAO(session)


    products = await ProductsDAO.list_all(session)





    await wh_dao.move_product(


        product_id=product_id,


        qty=qty,


        from_wh_id=from_wh,


        to_wh_id=to_wh,


    )





    await session.commit()


    await state.clear()





    await message.answer(


        f"РІСљвЂ¦ Р СџР ВµРЎР‚Р ВµР СР ВµРЎвЂ°Р ВµР Р…Р С‘Р Вµ Р Р†РЎвЂ№Р С—Р С•Р В»Р Р…Р ВµР Р…Р С•\n"


        f"Р СћР С•Р Р†Р В°РЎР‚ #{product_id}\n"


        f"{qty} РЎв‚¬РЎвЂљ."


    )





