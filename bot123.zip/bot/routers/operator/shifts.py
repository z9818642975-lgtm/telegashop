from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.filters.role import RoleFilter
from bot.dao.operator_shift_dao import OperatorShiftDAO, OperatorShiftStateError
from bot.keyboards.operator.main import operator_main_menu
from bot.fsm.operator_shift_fsm import OperatorShiftFSM

router = Router(name="operator_shift")

# ============================================================
# START SHIFT (STEP 1) РІР‚вЂќ Р С”Р Р…Р С•Р С—Р С”Р В° "СЂСџСџСћ Р вЂ™РЎвЂ№Р в„–РЎвЂљР С‘ Р Р…Р В° РЎРѓР СР ВµР Р…РЎС“"
# ============================================================

@router.message(
    RoleFilter("operator"),
    F.text == "СЂСџСџСћ Р вЂ™РЎвЂ№Р в„–РЎвЂљР С‘ Р Р…Р В° РЎРѓР СР ВµР Р…РЎС“",
)
async def start_shift_request(message, *, state: FSMContext | None = None,
):
    await state.set_state(OperatorShiftFSM.pickup_address)
    await message.answer(
        "СЂСџвЂњРЊ Р вЂ™Р Р†Р ВµР Т‘Р С‘РЎвЂљР Вµ Р В°Р Т‘РЎР‚Р ВµРЎРѓ РЎРѓР В°Р СР С•Р Р†РЎвЂ№Р Р†Р С•Р В·Р В°:",
    )

# ============================================================
# START SHIFT (STEP 2) РІР‚вЂќ Р Р†Р Р†Р С•Р Т‘ Р В°Р Т‘РЎР‚Р ВµРЎРѓР В°
# ============================================================

@router.message(
    RoleFilter("operator"),
    OperatorShiftFSM.pickup_address,
)
async def start_shift_confirm(message, *, state: FSMContext | None = None,
    session: AsyncSession | None = None,
    user,
):
    address = message.text.strip()
    if not address:
        await message.answer("РІСњРЉ Р С’Р Т‘РЎР‚Р ВµРЎРѓ Р Р…Р Вµ Р СР С•Р В¶Р ВµРЎвЂљ Р В±РЎвЂ№РЎвЂљРЎРЉ Р С—РЎС“РЎРѓРЎвЂљРЎвЂ№Р С")
        return

    shifts = OperatorShiftDAO(session)

    try:
        await shifts.start_shift(
            operator_id=user.id,
            pickup_address=address,
        )
    except OperatorShiftStateError:
        await message.answer(
            "РІС™В РїС‘РЏ Р РЋР СР ВµР Р…Р В° РЎС“Р В¶Р Вµ Р В°Р С”РЎвЂљР С‘Р Р†Р Р…Р В°",
            reply_markup=operator_main_menu(on_shift=True),
        )
        await state.clear()
        return

    await session.commit()
    await state.clear()

    await message.answer(
        f"РІСљвЂ¦ Р РЋР СР ВµР Р…Р В° Р Р…Р В°РЎвЂЎР В°РЎвЂљР В°\n\nСЂСџвЂњРЊ Р РЋР В°Р СР С•Р Р†РЎвЂ№Р Р†Р С•Р В·:\n{address}",
        reply_markup=operator_main_menu(on_shift=True),
    )

# ============================================================
# STOP SHIFT
# ============================================================

@router.message(
    RoleFilter("operator"),
    F.text == "РІРЏС‘ Р вЂ”Р В°Р С”РЎР‚РЎвЂ№РЎвЂљРЎРЉ РЎРѓР СР ВµР Р…РЎС“",
)
async def stop_shift(message, *, session: AsyncSession | None = None,
    user,
):
    shifts = OperatorShiftDAO(session)

    if not await shifts.is_on_shift(user.id):
        await message.answer(
            "РІС™В РїС‘РЏ Р РЋР СР ВµР Р…Р В° Р Р…Р Вµ Р В°Р С”РЎвЂљР С‘Р Р†Р Р…Р В°",
            reply_markup=operator_main_menu(on_shift=False),
        )
        return

    await shifts.stop_shift(operator_id=user.id)
    await session.commit()

    await message.answer(
        "СЂСџвЂќТ‘ Р РЋР СР ВµР Р…Р В° Р В·Р В°Р Р†Р ВµРЎР‚РЎв‚¬Р ВµР Р…Р В°",
        reply_markup=operator_main_menu(on_shift=False),
    )


