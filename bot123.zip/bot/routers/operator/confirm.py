from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models.order import Order
from bot.constants.order_status import OrderStatus
from bot.services.inventory import InventoryService
from bot.services.notifications import NotificationService
from bot.config import settings

router = Router(name="operator_confirm")

@router.callback_query(F.data.startswith("confirm:"))
async def confirm_order(
    cb: CallbackQuery,
    *,
    session: AsyncSession | None = None,
    bot,
):
    order_id = int(cb.data.split(":")[1])
    order = await session.get(Order, order_id)

    await InventoryService.deduct(session, order.id)
    order.status = OrderStatus.PAID

    await NotificationService.notify_client(
        bot,
        order.user_id,
        "вњ… Р’Р°С€ Р·Р°РєР°Р· РїРѕРґС‚РІРµСЂР¶РґС‘РЅ РѕРїРµСЂР°С‚РѕСЂРѕРј.",
    )

    await NotificationService.notify_admin(
        bot,
        list(settings.ADMINS)[0],
        f"рџ“¦ Р—Р°РєР°Р· #{order.id} РїРѕРґС‚РІРµСЂР¶РґС‘РЅ",
    )

    await cb.message.answer(f"вњ… Р—Р°РєР°Р· #{order.id} РїРѕРґС‚РІРµСЂР¶РґС‘РЅ")
    await cb.answer()

@router.callback_query(F.data.startswith("reject:"))
async def reject_order(
    cb: CallbackQuery,
    *,
    session: AsyncSession | None = None,
    bot,
):
    order_id = int(cb.data.split(":")[1])
    order = await session.get(Order, order_id)

    order.status = OrderStatus.REJECTED

    await NotificationService.notify_client(
        bot,
        order.user_id,
        "вќЊ Р—Р°РєР°Р· РѕС‚РєР»РѕРЅС‘РЅ. РџСЂРѕРІРµСЂСЊС‚Рµ С‡РµРє Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ СЃРЅРѕРІР°.",
    )

    await cb.message.answer(f"вќЊ Р—Р°РєР°Р· #{order.id} РѕС‚РєР»РѕРЅС‘РЅ")
    await cb.answer()

