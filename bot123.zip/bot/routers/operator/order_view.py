# bot/routers/operator/order_view.py
from aiogram import Router

# bot/routers/operator/order_view.py
from aiogram import Router


from aiogram.types import Message





router = Router(name="operator_order_view")








@router.message()


async def view_order(message: Message):


    await message.answer("Р СџРЎР‚Р С•РЎРѓР СР С•РЎвЂљРЎР‚ Р В·Р В°Р С”Р В°Р В·Р В°")




