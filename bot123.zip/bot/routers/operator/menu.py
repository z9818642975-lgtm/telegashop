# bot/routers/operator/menu.py
from aiogram import Router

# bot/routers/operator/menu.py
from aiogram import Router


from aiogram.types import Message





router = Router(name="operator_menu")








@router.message()


async def operator_menu(message: Message):


    await message.answer("Р С›Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚РЎРѓР С”Р С•Р Вµ Р СР ВµР Р…РЎР‹")




