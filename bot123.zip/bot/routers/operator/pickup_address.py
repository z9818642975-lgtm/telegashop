# bot/routers/operator/pickup_address.py
from aiogram import Router, F

# bot/routers/operator/pickup_address.py
from aiogram import Router, F


from aiogram.types import Message


from aiogram.fsm.context import FSMContext


from sqlalchemy.ext.asyncio import AsyncSession





from bot.filters.role import RoleFilter


from bot.states.operator_pickup import OperatorPickupState


from bot.dao.warehouses_dao import WarehousesDAO


from bot.dao.operator_shift_dao import OperatorShiftDAO


from bot.keyboards.operator.shift import on_shift_kb





router = Router(name="operator_pickup_address")








@router.message(RoleFilter("operator"), F.text == "СЂСџСџСћ Р СњР В°РЎвЂЎР В°РЎвЂљРЎРЉ РЎРѓР СР ВµР Р…РЎС“")


async def start_shift_or_request_address(message, *, session: AsyncSession | None = None,


    state: FSMContext | None = None,


    user,


):


    warehouses = WarehousesDAO(session)


    shifts = OperatorShiftDAO(session)





    wh = await warehouses.get_operator_wh(user.id)





    if wh and wh.address:


        # Р В°Р Т‘РЎР‚Р ВµРЎРѓ РЎС“Р В¶Р Вµ Р ВµРЎРѓРЎвЂљРЎРЉ РІвЂ вЂ™ РЎРѓРЎР‚Р В°Р В·РЎС“ РЎРѓРЎвЂљР В°РЎР‚РЎвЂљРЎС“Р ВµР С РЎРѓР СР ВµР Р…РЎС“


        await shifts.start_shift(


            operator_id=user.id,


            pickup_address=wh.address,


        )


        await session.commit()





        await message.answer(


            f"РІСљвЂ¦ Р РЋР СР ВµР Р…Р В° Р Р…Р В°РЎвЂЎР В°РЎвЂљР В°\nСЂСџвЂњРЊ Р РЋР В°Р СР С•Р Р†РЎвЂ№Р Р†Р С•Р В·:\n{wh.address}",


            reply_markup=on_shift_kb(),


        )


        return





    # Р В°Р Т‘РЎР‚Р ВµРЎРѓР В° Р Р…Р ВµРЎвЂљ РІвЂ вЂ™ Р В·Р В°Р С—РЎР‚Р В°РЎв‚¬Р С‘Р Р†Р В°Р ВµР С Р Р†Р Р†Р С•Р Т‘


    await state.set_state(OperatorPickupState.waiting_for_address)


    await message.answer(


        "СЂСџвЂњРЊ Р вЂ™Р Р†Р ВµР Т‘Р С‘РЎвЂљР Вµ Р В°Р Т‘РЎР‚Р ВµРЎРѓ РЎРѓР В°Р СР С•Р Р†РЎвЂ№Р Р†Р С•Р В·Р В° Р С•Р Т‘Р Р…Р С‘Р С РЎРѓР С•Р С•Р В±РЎвЂ°Р ВµР Р…Р С‘Р ВµР С:"


    )








@router.message(


    RoleFilter("operator"),


    OperatorPickupState.waiting_for_address,


)


async def save_pickup_address(message, *, session: AsyncSession | None = None,


    state: FSMContext | None = None,


    user,


):


    address = message.text.strip()





    if len(address) < 5:


        await message.answer("РІСњРЉ Р С’Р Т‘РЎР‚Р ВµРЎРѓ РЎРѓР В»Р С‘РЎв‚¬Р С”Р С•Р С Р С”Р С•РЎР‚Р С•РЎвЂљР С”Р С‘Р в„–, Р С—Р С•Р С—РЎР‚Р С•Р В±РЎС“Р в„–РЎвЂљР Вµ Р ВµРЎвЂ°РЎвЂ РЎР‚Р В°Р В·")


        return





    warehouses = WarehousesDAO(session)


    shifts = OperatorShiftDAO(session)





    await warehouses.set_operator_address(


        operator_id=user.id,


        address=address,


    )





    await shifts.start_shift(


        operator_id=user.id,


        pickup_address=address,


    )





    await session.commit()


    await state.clear()





    await message.answer(


        f"РІСљвЂ¦ Р С’Р Т‘РЎР‚Р ВµРЎРѓ РЎРѓР С•РЎвЂ¦РЎР‚Р В°Р Р…РЎвЂР Р…\nСЂСџвЂњРЊ Р РЋР В°Р СР С•Р Р†РЎвЂ№Р Р†Р С•Р В·:\n{address}\n\nР РЋР СР ВµР Р…Р В° Р Р…Р В°РЎвЂЎР В°РЎвЂљР В°",


        reply_markup=on_shift_kb(),


    )






