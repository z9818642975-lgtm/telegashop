from aiogram import Router

from .menu import router as menu_router
from .orders import router as orders_router
from .confirm import router as confirm_router

router = Router(name="operator")

router.include_router(menu_router)
router.include_router(orders_router)
router.include_router(confirm_router)
