from aiogram import Router, F
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.orders import OrdersDAO

router = Router(name="client_checkout")

@router.message(F.text == "СЂСџВ§С• Р С›РЎвЂћР С•РЎР‚Р СР С‘РЎвЂљРЎРЉ Р В·Р В°Р С”Р В°Р В·")
async def checkout(message: Message, *, session: AsyncSession | None = None, user):
    await message.answer("СЂСџвЂњР‹ Р СџРЎР‚Р С‘РЎв‚¬Р В»Р С‘РЎвЂљР Вµ РЎвЂћР С•РЎвЂљР С• Р С‘Р В»Р С‘ РЎвЂћР В°Р в„–Р В» РЎвЂЎР ВµР С”Р В°.")

@router.message(F.photo)
async def upload_receipt(message: Message, *, session: AsyncSession | None = None, user):
    order = await OrdersDAO.get_draft(session, user.id)
    await OrdersDAO.submit(
        session,
        order,
        receipt_id=message.photo[-1].file_id,
    )
    await message.answer("РІСљвЂ¦ Р В§Р ВµР С” Р С—Р С•Р В»РЎС“РЎвЂЎР ВµР Р…. Р С›Р В¶Р С‘Р Т‘Р В°Р в„–РЎвЂљР Вµ Р С—Р С•Р Т‘РЎвЂљР Р†Р ВµРЎР‚Р В¶Р Т‘Р ВµР Р…Р С‘РЎРЏ Р С•Р С—Р ВµРЎР‚Р В°РЎвЂљР С•РЎР‚Р В°.")

