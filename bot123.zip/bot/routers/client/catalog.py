from aiogram import Router, F
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models.user import User
from bot.services.catalog_service import show_catalog

router = Router(name="client_catalog")


@router.message(F.text == "СЂСџвЂњВ¦ Р С™Р В°РЎвЂљР В°Р В»Р С•Р С–")
async def catalog(
    message: Message,
    *,
    session: AsyncSession,
    user: User,
) -> None:
    await show_catalog(
        message=message,
        session=session,
        user=user,
    )
