from aiogram import Router
from aiogram.types import Message
from bot.config import settings

router = Router(name="chat")

@router.message()
async def relay(message: Message):
    # СѓРїСЂРѕС‰С‘РЅРЅС‹Р№ РїСЂРѕРєСЃРё-С‡Р°С‚
    if message.reply_to_message:
        await message.answer("рџ’¬ РЎРѕРѕР±С‰РµРЅРёРµ РїРµСЂРµРґР°РЅРѕ РѕРїРµСЂР°С‚РѕСЂСѓ")
