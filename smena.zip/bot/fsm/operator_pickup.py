from aiogram.fsm.state import StatesGroup, State


class OperatorPickupFSM(StatesGroup):
    address = State()
    description = State()
    photo = State()
    confirm = State()
    comment = State()
