﻿from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def delivery_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📦 Самовывоз", callback_data="delivery:pickup"),
                InlineKeyboardButton(text="🚚 Доставка", callback_data="delivery:courier"),
            ],
            [
                InlineKeyboardButton(text="в¬…пёЏ РќР°Р·Р°Рґ", callback_data="back"),
            ],
        ]
    )
