﻿from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def profile_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📦 Мои заказы", callback_data="profile:orders"),
                InlineKeyboardButton(text="🎁 Рефералка", callback_data="profile:ref"),
            ],
            [
                InlineKeyboardButton(text="🏷 Купон", callback_data="profile:coupon"),
                InlineKeyboardButton(text="в¬…пёЏ РќР°Р·Р°Рґ", callback_data="back"),
            ],
        ]
    )
