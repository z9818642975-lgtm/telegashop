﻿from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.constants.callbacks import CB


def checkout_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Оформить заказ",
                    callback_data=CB.CART_CHECKOUT,
                )
            ],
            [
                InlineKeyboardButton(
                    text="⬅️ В корзину",
                    callback_data=CB.CART_OPEN,
                )
            ],
        ]
    )


def delivery_type_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🏬 Самовывоз",
                    callback_data=CB.DELIVERY_PICKUP,
                )
            ],
            [
                InlineKeyboardButton(
                    text="🚚 Курьер",
                    callback_data=CB.DELIVERY_COURIER,
                )
            ],
        ]
    )


def delivery_price_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💰 1000 ₽",
                    callback_data=CB.DELIVERY_PRICE.format(amount=1000),
                )
            ],
            [
                InlineKeyboardButton(
                    text="💰 1500 ₽",
                    callback_data=CB.DELIVERY_PRICE.format(amount=1500),
                )
            ],
        ]
    )
