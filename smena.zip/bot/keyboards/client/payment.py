﻿# bot/keyboards/client/payment.py

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.constants.callbacks import CB


def payment_method_kb() -> InlineKeyboardMarkup:
    """
    Выбор способа оплаты
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💳 Банк",
                    callback_data=CB.PAY_BANK.format(bank_id="any"),
                )
            ],
            [
                InlineKeyboardButton(
                    text="⚡ СБП",
                    callback_data=CB.PAY_SBP,
                )
            ],
        ]
    )


def payment_confirm_kb() -> InlineKeyboardMarkup:
    """
    Подтверждение или отмена оплаты
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Подтвердить",
                    callback_data=CB.PAYMENT_DONE,
                )
            ],
            [
                InlineKeyboardButton(
                    text="❌ Отменить",
                    callback_data=CB.PAYMENT_CANCEL,
                )
            ],
        ]
    )


# Каноничные имена для client/__init__.py
def payment_kb() -> InlineKeyboardMarkup:
    return payment_method_kb()
