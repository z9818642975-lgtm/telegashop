from aiogram import Router
from aiogram.types import Message

from bot.keyboards.client.main import client_main_menu
from bot.models.user import User

router = Router(name="start")


@router.message(commands=["start"])
async def cmd_start(message: Message, user: User):
    await message.answer(
        "👋 Добро пожаловать!",
        reply_markup=client_main_menu(),
    )
