from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.constants.callbacks import CB
from bot.dao.orders_dao import OrdersDAO
from bot.keyboards.client.cart import cart_inline_kb
from bot.routers.client.catalog import render_catalog
from bot.models.user import User

router = Router(name="client_cart")


# =========================================================
# OPEN CART
# =========================================================

@router.callback_query(F.data == CB.CART_OPEN)
async def open_cart(
    cb: CallbackQuery,
    session: AsyncSession,
    user: User,
):
    order = await OrdersDAO.get_cart(session, user.id)

    if not order or not order.items:
        await render_catalog(cb, session)
        return

    await cb.message.edit_text(
        "🧺 Корзина",
        reply_markup=cart_inline_kb(order.items),
    )


# =========================================================
# CLEAR CART
# =========================================================

@router.callback_query(F.data == CB.CART_CLEAR)
async def clear_cart(
    cb: CallbackQuery,
    session: AsyncSession,
    user: User,
):
    order = await OrdersDAO.get_cart(session, user.id)

    if order:
        for item in list(order.items):
            await OrdersDAO.remove_item(session, item.id)

        await session.commit()

    await render_catalog(cb, session)


# =========================================================
# REMOVE ITEM
# =========================================================

@router.callback_query(F.data.startswith("item:remove:"))
async def remove_item(
    cb: CallbackQuery,
    session: AsyncSession,
    user: User,
):
    await cb.answer()

    item_id = int(cb.data.split(":")[-1])

    await OrdersDAO.remove_item(
        session=session,
        item_id=item_id,
    )

    await session.commit()

    # перерисовываем корзину
    order = await OrdersDAO.get_cart(session, user.id)

    if not order or not order.items:
        await render_catalog(cb, session)
        return

    await cb.message.edit_text(
        "🧺 Корзина",
        reply_markup=cart_inline_kb(order.items),
    )
