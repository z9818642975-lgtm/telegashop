from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.orders_dao import OrdersDAO
from bot.models.user import User
from bot.routers.client.catalog import render_catalog_cb

router = Router(name="client_quantity")


@router.callback_query(F.data.startswith("qty:"))
async def select_quantity(
    cb: CallbackQuery,
    session: AsyncSession,
    user: User,   # ✅ ОБЯЗАТЕЛЬНО
):
    """
    qty:{product_id}:{qty}
    """
    await cb.answer()

    _, product_id, qty = cb.data.split(":")
    product_id = int(product_id)
    qty = int(qty)

    # корзина пользователя
    order = await OrdersDAO.get_or_create_cart(session, user)

    # добавляем позицию
    await OrdersDAO.add_item(
        session=session,
        order_id=order.id,
        product_id=product_id,
        qty=qty,
    )

    # inline-возврат в каталог
    await render_catalog_cb(cb, session)
