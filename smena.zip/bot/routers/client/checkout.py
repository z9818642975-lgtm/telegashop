from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.constants.callbacks import CB
from bot.keyboards.client.checkout import delivery_type_kb
from bot.dao.orders_dao import OrdersDAO
from bot.dao.operator_shift_dao import OperatorShiftDAO
from bot.fsm.checkout_fsm import CheckoutFSM

router = Router(name="client_checkout")


@router.callback_query(F.data == CB.CART_CHECKOUT)
async def checkout_start(
    cb: CallbackQuery,
    state: FSMContext,
    session: AsyncSession,
):
    order = await OrdersDAO.get_cart(session, cb.from_user.id)
    if not order or not order.items:
        await cb.answer("Корзина пуста", show_alert=True)
        return

    await state.set_state(CheckoutFSM.delivery)

    await cb.message.edit_text(
        "🚚 Выберите способ получения:",
        reply_markup=delivery_type_kb(),
    )


# ============================================================
# PICKUP
# ============================================================

@router.callback_query(
    CheckoutFSM.delivery,
    F.data == CB.DELIVERY_PICKUP,
)
async def select_pickup(
    cb: CallbackQuery,
    state: FSMContext,
    session: AsyncSession,
):
    order = await OrdersDAO.get_cart(session, cb.from_user.id)
    if not order:
        return

    operator_id = order.operator_id
    if not operator_id:
        await cb.answer(
            "Самовывоз временно недоступен",
            show_alert=True,
        )
        return

    shift = await OperatorShiftDAO.get_active(session, operator_id)
    if not shift:
        await cb.answer(
            "Самовывоз временно недоступен",
            show_alert=True,
        )
        return

    # 1️⃣ карточка самовывоза
    text = "📍 Самовывоз\n\n" + shift.pickup_address

    if shift.pickup_description:
        text += f"\n\n📝 {shift.pickup_description}"

    await cb.message.edit_text(text)

    # 2️⃣ фото (если есть)
    for photo_id in shift.pickup_photos or []:
        await cb.message.answer_photo(photo_id)

    # 3️⃣ сохраняем выбор
    await state.update_data(
        pickup_address=shift.pickup_address,
    )

    await state.set_state(CheckoutFSM.payment)

    await cb.message.answer(
        "💳 Выберите способ оплаты",
    )
