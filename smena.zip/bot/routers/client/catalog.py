from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.exceptions import TelegramBadRequest
from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.products_dao import ProductsDAO
from bot.keyboards.client.catalog import catalog_kb
from bot.keyboards.client.quantity import quantity_kb

router = Router(name="client_catalog")


# ===== REPLY → Message =====
@router.message(F.text == "📦 Каталог")
async def open_catalog_from_menu(message: Message, session: AsyncSession):
    products = await ProductsDAO.get_active(session)
    await message.answer(
        "📦 Каталог",
        reply_markup=catalog_kb(products),
    )


# ===== INLINE → CallbackQuery =====
@router.callback_query(F.data == "catalog")
async def open_catalog(cb: CallbackQuery, session: AsyncSession):
    await render_catalog(cb, session)


async def render_catalog(cb: CallbackQuery, session: AsyncSession):
    products = await ProductsDAO.get_active(session)
    try:
        await cb.message.edit_text(
            "📦 Каталог",
            reply_markup=catalog_kb(products),
        )
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("product:"))
async def open_product(cb: CallbackQuery, session: AsyncSession):
    product_id = int(cb.data.split(":")[1])

    product = await ProductsDAO.get_by_id(session, product_id)
    if not product:
        return

    text = (
        f"<b>{product.title}</b>\n\n"
        f"{product.description or ''}\n\n"
        f"💰 {product.base_price} ₽\n\n"
        f"Выберите количество:"
    )

    try:
        await cb.message.edit_text(
            text,
            reply_markup=quantity_kb(product_id),
        )
    except TelegramBadRequest:
        pass
