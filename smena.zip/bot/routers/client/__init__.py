# bot/routers/client/__init__.py

from aiogram import Router

from .menu import router as menu_router
from .catalog import router as catalog_router
from .cart import router as cart_router
from .checkout import router as checkout_router
from .payment import router as payment_router
from .quantity import router as quantity_router

router = Router(name="client")

router.include_router(menu_router)
router.include_router(catalog_router)
router.include_router(cart_router)
router.include_router(checkout_router)
router.include_router(payment_router)
router.include_router(quantity_router)

__all__ = ["router"]
