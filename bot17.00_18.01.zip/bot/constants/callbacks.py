class CB:
    # ===== common =====
    BACK_MENU = "back:menu"
    BACK_CATALOG = "back:catalog"
    BACK_PRODUCT = "back:product:{id}"

    # ===== catalog =====
    CATALOG_OPEN = "catalog:open"
    PRODUCT = "product:{id}"
    PRODUCT_QTY = "product_qty"
    QTY = "qty:{id}:{qty}"

    # ===== cart =====
    CART_OPEN = "cart:open"
    CART_CLEAR = "cart:clear"
    CART_CHECKOUT = "cart:checkout"
    CART_REMOVE = "cart:remove"

    # ===== delivery =====
    DELIVERY_PICKUP = "delivery:pickup"
    DELIVERY_COURIER = "delivery:courier"

    # ===== payment =====
    PAY_BANK = "pay:bank:{bank_id}"
    PAY_SBP = "pay:sbp"
    PAYMENT_CASH = "payment:cash"
    PAYMENT_CARD = "payment:card"
    PAYMENT_DONE = "payment:done"
    PAYMENT_CANCEL = "payment:cancel"

    # ===== operator =====
    OP_ALIVE = "op:alive"

    OP_SHIFT_START = "op:shift:start"
    OP_SHIFT_CONFIRM = "op:shift:confirm"
    OP_SHIFT_CANCEL = "op:shift:cancel"
    OP_SHIFT_STOP = "op:shift:stop"
    OP_SHIFT_EDIT_ADDRESS = "op:shift:edit_address"

    OP_CHECK_ACCEPT = "op:order:accept:{id}"
    OP_READY = "op:order:ready:{id}"
    OP_SENT = "op:order:sent:{id}"

    # ===== admin =====
    ADMIN_PRODUCTS = "admin:products"
    ADMIN_WAREHOUSES = "admin:warehouses"
    ADMIN_OPERATORS = "admin:operators"
