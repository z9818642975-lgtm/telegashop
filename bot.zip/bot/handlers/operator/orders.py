from aiogram import Router, F
from aiogram.types import CallbackQuery

router = Router()

@router.callback_query(F.data == "op:accept")
async def accept_order(call: CallbackQuery):
    await call.message.edit_text("✅ Заказ принят оператором")

@router.callback_query(F.data == "op:paid")
async def paid_order(call: CallbackQuery):
    await call.message.edit_text("💰 Оплата подтверждена")

@router.callback_query(F.data == "op:done")
async def done_order(call: CallbackQuery):
    await call.message.edit_text("🏁 Заказ завершён")
