import json
from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.middlewares.role import RoleFilter
from bot.models.order import Order
from bot.services.warehouse_service import WarehouseService
from bot.services.shift_service import ShiftService
from bot.services.notify_service import NotifyService

router = Router()

def _parse_items(order: Order) -> dict:
    if getattr(order, "items_json", None):
        try:
            return json.loads(order.items_json) if isinstance(order.items_json, str) else dict(order.items_json)
        except Exception:
            return {}
    return {}

@router.callback_query(RoleFilter("operator"), F.data.startswith("op:accept:"))
async def op_accept(cb: CallbackQuery, session: AsyncSession):
    order_id = int(cb.data.split(":")[-1])
    order = await session.get(Order, order_id)
    if not order:
        await cb.answer("Заказ не найден", show_alert=True)
        return

    # Require accepted check if field exists
    if getattr(order, "check_status", None) and order.check_status != "ACCEPTED":
        await cb.answer("Сначала нужен принятый чек", show_alert=True)
        return

    ss = ShiftService(session)
    if not await ss.is_on_shift(cb.from_user.id):
        await cb.answer('❌ Вы не на смене', show_alert=True)
        return

    ws = WarehouseService(session)
    try:
        op_wh = await ws.get_operator_wh_or_raise(cb.from_user.id)
        items = _parse_items(order)
        # items may be name->qty; if so we cannot map to product_id. Try also order.product_id fields.
        # If your items_json stores product_id->qty, it works. Otherwise admin can test with single product_id order.
        for k, qty in items.items():
            try:
                pid = int(k)
            except Exception:
                # cannot validate by id; skip validation
                continue
            await ws.require_has_stock(op_wh.id, pid, int(qty))
        # mark operator assigned
        if hasattr(order, "operator_id"):
            order.operator_id = cb.from_user.id
        order.status = "ACCEPTED"
        await session.commit()
    except Exception as e:
        await session.rollback()
        await cb.answer(f"❌ Нельзя принять: {e}", show_alert=True)
        return

    await cb.message.edit_text(f"✅ Принято. Заказ №{order.id}")
    await NotifyService(cb.bot, session).notify_client(order.user_id, f"✅ Оператор принял заказ №{order.id}")

@router.callback_query(RoleFilter("operator"), F.data.startswith("op:finish:"))
async def op_finish(cb: CallbackQuery, session: AsyncSession):
    order_id = int(cb.data.split(":")[-1])
    order = await session.get(Order, order_id)
    if not order:
        await cb.answer("Заказ не найден", show_alert=True)
        return

    # only assigned operator can finish if operator_id exists
    if hasattr(order, "operator_id") and order.operator_id and order.operator_id != cb.from_user.id:
        await cb.answer("Это не ваш заказ", show_alert=True)
        return

    ss = ShiftService(session)
    if not await ss.is_on_shift(cb.from_user.id):
        await cb.answer('❌ Вы не на смене', show_alert=True)
        return

    ws = WarehouseService(session)
    try:
        # deduct from operator warehouse to client
        items = _parse_items(order)
        for k, qty in items.items():
            try:
                pid = int(k)
            except Exception:
                continue
            await ws.deduct_from_operator_for_client(cb.from_user.id, pid, int(qty))
        order.status = "DONE"
        await session.commit()
    except Exception as e:
        await session.rollback()
        await cb.answer(f"❌ Нельзя завершить: {e}", show_alert=True)
        return

    await cb.message.edit_text(f"🏁 Завершено. Заказ №{order.id}")
    await NotifyService(cb.bot, session).notify_client(order.user_id, f"🏁 Заказ №{order.id} завершён")
