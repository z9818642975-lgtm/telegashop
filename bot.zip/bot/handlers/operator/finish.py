from aiogram import Router, F
from aiogram.types import CallbackQuery
from bot.models.order import Order

router = Router()

@router.callback_query(F.data.startswith("op_finish:"))
async def finish(cb: CallbackQuery, session):
    order = await session.get(Order, int(cb.data.split(":")[1]))
    order.status = "done"
    await session.commit()
    await cb.message.answer("✅ Заказ завершён, зарплата начислена")