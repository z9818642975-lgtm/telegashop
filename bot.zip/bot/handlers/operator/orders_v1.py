# -*- coding: utf-8 -*-
from __future__ import annotations

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from bot.models.order import Order
from bot.keyboards.inline.operator_orders_v1 import orders_list_kb, order_actions_kb

router = Router(name="operator_orders_v1")


@router.message(Command("op_orders"))
async def op_orders(message: Message, session: AsyncSession) -> None:
    res = await session.execute(
        select(Order).where(Order.status.in_(["PAID", "IN_WORK", "PAID_CONFIRMED"]))
        .order_by(Order.id.desc())
        .limit(20)
    )
    orders = list(res.scalars().all())

    if not orders:
        await message.answer("Заказов нет.")
        return

    await message.answer("Заказы (V1):", reply_markup=orders_list_kb(orders))


@router.callback_query(F.data.startswith("op:open:"))
async def op_open_order(cb: CallbackQuery, session: AsyncSession) -> None:
    order_id = int(cb.data.split(":")[2])
    res = await session.execute(select(Order).where(Order.id == order_id))
    order = res.scalar_one_or_none()
    if not order:
        await cb.answer("Заказ не найден", show_alert=True)
        return

    text = (
        f"Заказ #{order.id}\n"
        f"Статус: {order.status}\n"
        f"Оплачен: {'да' if order.is_paid else 'нет'}\n"
        f"Сумма: {order.total_price} ₽\n\n"
        f"Комментарий:\n{order.comment or '—'}"
    )
    await cb.message.edit_text(text, reply_markup=order_actions_kb(order))
    await cb.answer()


@router.callback_query(F.data.startswith("op:accept:"))
async def op_accept(cb: CallbackQuery, session: AsyncSession) -> None:
    order_id = int(cb.data.split(":")[2])

    await session.execute(
        update(Order)
        .where(Order.id == order_id)
        .values(operator_id=cb.from_user.id, status="IN_WORK")
    )
    await session.commit()

    await cb.answer("Принято ✅")
    await op_open_order(cb, session)


@router.callback_query(F.data.startswith("op:paid:"))
async def op_mark_paid(cb: CallbackQuery, session: AsyncSession) -> None:
    order_id = int(cb.data.split(":")[2])

    await session.execute(
        update(Order)
        .where(Order.id == order_id)
        .values(is_paid=True, status="PAID_CONFIRMED")
    )
    await session.commit()

    await cb.answer("Оплата подтверждена ✅")
    await op_open_order(cb, session)


@router.callback_query(F.data.startswith("op:finish:"))
async def op_finish(cb: CallbackQuery, session: AsyncSession) -> None:
    order_id = int(cb.data.split(":")[2])

    await session.execute(
        update(Order)
        .where(Order.id == order_id)
        .values(status="DONE")
    )
    await session.commit()

    await cb.message.edit_text(f"Заказ #{order_id} завершён ✅")
    await cb.answer()
