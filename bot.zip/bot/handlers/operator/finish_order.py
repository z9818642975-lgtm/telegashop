from aiogram import Router, types
from sqlalchemy import select
from bot.core.db import async_session_maker
from bot.models.order import Order
from bot.services.salary_service import SalaryService

router = Router()

@router.message(lambda m: m.text.startswith("FINISH:"))
async def finish(message: types.Message):
    order_id = int(message.text.split(":")[1])
    async with async_session_maker() as session:
        order = (await session.execute(select(Order).where(Order.id==order_id))).scalar_one()
        order.status = "DONE"
        salary = SalaryService.calc(order.total_price)
        await session.commit()
    await message.answer(f"✅ Заказ #{order_id} завершён\n💰 Зарплата: {salary} ₽")
