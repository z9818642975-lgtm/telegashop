from aiogram import Router

router = Router(name="stock_flow")

# ❌ НИКАКИХ include_router ТУТ
# ❌ НИКАКИХ импортов operator_router
