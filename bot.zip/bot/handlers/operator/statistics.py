# -*- coding: utf-8 -*-
from __future__ import annotations

from aiogram import Router, F
from aiogram.types import Message
from sqlalchemy import select, func

from bot.models.order import Order
from bot.models.operator_shift import OperatorShift

router = Router()

@router.message(F.text == "📊 Статистика")
async def operator_stats(message: Message, session):
    operator_id = message.from_user.id

    # Заказы сегодня
    orders_today = await session.scalar(
        select(func.count(Order.id))
        .where(Order.operator_id == operator_id)
    )

    paid_orders = await session.scalar(
        select(func.count(Order.id))
        .where(
            Order.operator_id == operator_id,
            Order.is_paid == True
        )
    )

    # 💰 Зарплата V1
    salary = paid_orders * 1000

    await message.answer(
        "📊 <b>Статистика оператора</b>\n\n"
        f"Заказов: {orders_today}\n"
        f"Оплачено: {paid_orders}\n"
        f"💰 Зарплата: {salary} ₽"
    )
