# -*- coding: utf-8 -*-
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message

from bot.keyboards.reply.operator_menu import operator_main_menu

router = Router(name="operator_start")


@router.message(Command("op"))
async def operator_entry(message: Message) -> None:
    await message.answer(
        "🧑‍💼 Оператор (V1)\n"
        "Используйте кнопки меню или команды:\n"
        "/op_orders — заказы\n"
        "/op_stats — зарплата и статистика\n",
        reply_markup=operator_main_menu(),
    )


# --- Reply-menu actions (чтобы кнопки не молчали) ---
@router.message(F.text == "📦 Заказы")
async def operator_orders_btn(message: Message, session):
    # Повторяем поведение /op_orders, чтобы кнопка работала
    from bot.handlers.operator.orders_v1 import op_orders
    await op_orders(message, session)


@router.message(F.text == "📊 Зарплата и статистика")
async def operator_stats_btn(message: Message, session):
    from bot.handlers.operator.stats_v1 import op_stats
    await op_stats(message, session)


@router.message(F.text == "🟢 Начать смену")
async def operator_shift_start_btn(message: Message) -> None:
    await message.answer("Смена: старт (V1) — логика смен в разработке.")


@router.message(F.text == "🔚 Завершить смену")
async def operator_shift_end_btn(message: Message) -> None:
    await message.answer("Смена: завершение (V1) — логика смен в разработке.")


@router.message(F.text == "📦 Склад")
async def operator_stock_btn(message: Message) -> None:
    await message.answer("Склад (V1) — раздел в разработке.")
