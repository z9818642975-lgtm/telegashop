
from aiogram import Router, F
from aiogram.types import CallbackQuery
from bot.models.order import Order
from bot.middlewares.role import RoleFilter
from sqlalchemy.ext.asyncio import AsyncSession

router = Router()

@router.callback_query(F.data.startswith("op:check:accept"), RoleFilter("operator"))
async def accept_check(cb: CallbackQuery, session: AsyncSession):
    order_id = int(cb.data.split(":")[-1])
    order = await session.get(Order, order_id)
    order.check_status = "ACCEPTED"
    order.status = "PAID"
    order.is_paid = True
    await session.commit()
    await cb.message.edit_text(f"✅ Чек принят\nЗаказ №{order.id}")
    await cb.bot.send_message(order.user_id, f"✅ Ваш чек принят. Заказ №{order.id} в работе")

@router.callback_query(F.data.startswith("op:check:reject"), RoleFilter("operator"))
async def reject_check(cb: CallbackQuery, session: AsyncSession):
    order_id = int(cb.data.split(":")[-1])
    order = await session.get(Order, order_id)
    order.check_status = "REJECTED"
    await session.commit()
    await cb.message.edit_text(f"❌ Чек отклонён\nЗаказ №{order.id}")
    await cb.bot.send_message(order.user_id, "❌ Чек отклонён. Пришлите корректный чек.")
