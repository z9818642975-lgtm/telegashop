from aiogram import Router

from .start import router as start_router
from .orders_v1 import router as orders_router
from .checks import router as checks_router
from .shift import router as shift_router

from .order_stock_flow import router as stock_flow_router

router = Router(name="operator")
router.include_router(start_router)
router.include_router(shift_router)
router.include_router(orders_router)
router.include_router(checks_router)

router.include_router(stock_flow_router)
