# -*- coding: utf-8 -*-
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from bot.models.order import Order

router = Router(name="operator_stats_v1")


@router.message(Command("op_stats"))
async def op_stats(message: Message, session: AsyncSession) -> None:
    operator_id = message.from_user.id

    # V1: считаем завершённые и оплаченные
    res_done = await session.execute(
        select(func.count(Order.id)).where(
            Order.operator_id == operator_id,
            Order.status == "DONE",
            Order.is_paid.is_(True),
        )
    )
    done = int(res_done.scalar() or 0)

    # V1 зарплата (пока блок заложен):
    # 1000 ₽ за заказ (можем позже заменить на формулы по SKU/кол-ву)
    salary = done * 1000

    await message.answer(
        "📊 Статистика оператора\n\n"
        f"Заказов завершено (PAID+DONE): {done}\n"
        f"Зарплата: {salary} ₽ (V1: 1000 ₽ за заказ)\n"
    )
