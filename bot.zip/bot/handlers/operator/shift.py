from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.middlewares.role import RoleFilter
from bot.dao.warehouses_dao import WarehousesDAO
from bot.fsm.operator_shift_fsm import OperatorShiftFSM

router = Router()

@router.message(RoleFilter("operator"), F.text == "🟢 Выйти на смену")
async def start_shift(message: Message, state: FSMContext, session: AsyncSession):
    dao = WarehousesDAO(session)
    wh = await dao.get_operator_wh(message.from_user.id)
    if not wh or not (wh.address and wh.address.strip()):
        await state.set_state(OperatorShiftFSM.wait_address)
        await message.answer("📍 Введите адрес самовывоза (адрес вашего склада):")
        return

    # shift start logic may already exist; we keep minimal ack
    await message.answer(f"✅ Смена начата. Самовывоз: {wh.address}")

@router.message(RoleFilter("operator"), OperatorShiftFSM.wait_address)
async def set_address(message: Message, state: FSMContext, session: AsyncSession):
    addr = message.text.strip()
    dao = WarehousesDAO(session)
    wh = await dao.get_operator_wh(message.from_user.id)
    if wh:
        await dao.set_address(wh.id, addr)
    else:
        await dao.create_operator_wh(
            operator_tg_id=message.from_user.id,
            title=f"🏬 Склад оператора {message.from_user.id}",
            address=addr,
        )
    await session.commit()
    await state.clear()
    await message.answer(f"✅ Адрес самовывоза сохранён: {addr}\nТеперь нажмите «🟢 Выйти на смену» ещё раз.")
