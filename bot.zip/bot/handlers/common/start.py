# ============================================================
# bot/handlers/common/start.py
# ============================================================

from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from bot.models.user import UserRole
from bot.keyboards.reply.client_menu import client_main_menu
from bot.keyboards.reply.operator_menu import operator_main_menu
from bot.keyboards.reply.admin_menu import admin_main_menu

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, role: UserRole):
    """
    Стартовое меню в зависимости от роли
    Роль приходит из RoleMiddleware
    """

    if role == UserRole.ADMIN:
        await message.answer(
            "🛠 Админ-панель",
            reply_markup=admin_main_menu(),
        )
        return

    if role == UserRole.OPERATOR:
        await message.answer(
            "🧑‍💼 Операторское меню",
            reply_markup=operator_main_menu(),
        )
        return

    # 👇 CLIENT — ВСЕГДА ПО УМОЛЧАНИЮ
    await message.answer(
        "👋 Добро пожаловать!",
        reply_markup=client_main_menu(),
    )
