import re
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.middlewares.role import RoleFilter
from bot.fsm.admin_fsm import AdminFSM
from bot.services.warehouse_service import WarehouseService

router = Router()

@router.callback_query(RoleFilter("admin"), F.data == "admin:tr:start")
async def tr_start(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdminFSM.tr_from_wh)
    await cb.message.edit_text("Введите ID склада-источника (например 1):")

@router.message(RoleFilter("admin"), AdminFSM.tr_from_wh)
async def tr_step1(message: Message, state: FSMContext):
    try:
        from_wh = int(message.text.strip())
    except Exception:
        await message.answer("Нужно число.")
        return
    await state.update_data(tr_from_wh=from_wh)
    await state.set_state(AdminFSM.tr_to_wh)
    await message.answer("Введите ID склада-получателя:")

@router.message(RoleFilter("admin"), AdminFSM.tr_to_wh)
async def tr_step2(message: Message, state: FSMContext):
    try:
        to_wh = int(message.text.strip())
    except Exception:
        await message.answer("Нужно число.")
        return
    await state.update_data(tr_to_wh=to_wh)
    await state.set_state(AdminFSM.tr_product_id)
    await message.answer("Введите ID товара (product_id):")

@router.message(RoleFilter("admin"), AdminFSM.tr_product_id)
async def tr_step3(message: Message, state: FSMContext):
    try:
        pid = int(message.text.strip())
    except Exception:
        await message.answer("Нужно число.")
        return
    await state.update_data(tr_product_id=pid)
    await state.set_state(AdminFSM.tr_qty)
    await message.answer("Введите количество для перемещения:")

@router.message(RoleFilter("admin"), AdminFSM.tr_qty)
async def tr_step4(message: Message, state: FSMContext, session: AsyncSession):
    try:
        qty = int(message.text.strip())
    except Exception:
        await message.answer("Нужно число.")
        return
    data = await state.get_data()
    from_wh = int(data["tr_from_wh"])
    to_wh = int(data["tr_to_wh"])
    pid = int(data["tr_product_id"])

    svc = WarehouseService(session)
    try:
        await svc.admin_move_stock(from_wh, to_wh, pid, qty, admin_tg_id=message.from_user.id)
        await session.commit()
    except Exception as e:
        await session.rollback()
        await message.answer(f"❌ Ошибка перемещения: {e}")
        return

    await state.clear()
    await message.answer(f"✅ Перемещение выполнено: {from_wh} → {to_wh}, товар {pid}, qty={qty}")
