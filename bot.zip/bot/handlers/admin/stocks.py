from aiogram import Router, F
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from bot.middlewares.role import RoleFilter
from bot.dao.warehouses_dao import WarehousesDAO

router = Router()

@router.callback_query(RoleFilter("admin"), F.data == "admin:stock:view")
async def stock_view(cb: CallbackQuery, session: AsyncSession):
    dao = WarehousesDAO(session)
    whs = await dao.list_active()
    # simple SQL for a compact report
    q = text("""
        SELECT w.id as wh_id, w.title as wh_title, wp.product_id as product_id, wp.qty_available as qty
        FROM warehouse_products wp
        JOIN warehouses w ON w.id = wp.warehouse_id
        ORDER BY w.id ASC, wp.product_id ASC
    """)
    res = await session.execute(q)
    rows = res.fetchall()

    lines = ["📊 Остатки:"]
    if not rows:
        lines.append("— пусто —")
    else:
        cur = None
        for r in rows:
            if cur != r.wh_id:
                cur = r.wh_id
                lines.append(f"\n🏬 #{r.wh_id} {r.wh_title}")
            lines.append(f"• product_id={r.product_id} → {r.qty} шт")
    await cb.message.edit_text("\n".join(lines))
