from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.middlewares.role import RoleFilter
from bot.dao.operators_dao import OperatorsDAO
from bot.fsm.admin_fsm import AdminFSM
from bot.keyboards.inline.admin_warehouses import operators_list_kb, operator_manage_kb

router = Router()

@router.callback_query(RoleFilter("admin"), F.data == "admin:op:list")
async def op_list(cb: CallbackQuery, session: AsyncSession):
    dao = OperatorsDAO(session)
    ops = await dao.list_active()
    text = "👥 Операторы:\n" + ("\n".join([f"{o.name} ({o.tg_id})" for o in ops]) if ops else "— пусто —")
    await cb.message.edit_text(text, reply_markup=operators_list_kb(ops))

@router.callback_query(RoleFilter("admin"), F.data == "admin:op:add")
async def op_add(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdminFSM.op_tg_id)
    await cb.message.edit_text("Введите TG ID оператора (число):")

@router.message(RoleFilter("admin"), AdminFSM.op_tg_id)
async def op_add_step1(message: Message, state: FSMContext):
    try:
        tg_id = int(message.text.strip())
    except Exception:
        await message.answer("Нужно число TG ID.")
        return
    await state.update_data(op_tg_id=tg_id)
    await state.set_state(AdminFSM.op_name)
    await message.answer("Введите имя оператора:")

@router.message(RoleFilter("admin"), AdminFSM.op_name)
async def op_add_step2(message: Message, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    tg_id = int(data["op_tg_id"])
    name = message.text.strip()
    dao = OperatorsDAO(session)
    await dao.upsert(tg_id, name)
    await session.commit()
    await state.clear()
    await message.answer("✅ Оператор сохранён. Откройте '🛠 Админ панель' → '👥 Операторы'.")

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:op:open:"))
async def op_open(cb: CallbackQuery, session: AsyncSession):
    tg_id = int(cb.data.split(":")[-1])
    dao = OperatorsDAO(session)
    op = await dao.get_by_tg(tg_id)
    if not op:
        await cb.answer("Оператор не найден", show_alert=True)
        return
    text = f"👤 Оператор\nИмя: {op.name}\nTG ID: {op.tg_id}\nСтатус: {'🟢 активен' if op.is_active else '🔴 архив'}"
    await cb.message.edit_text(text, reply_markup=operator_manage_kb(op.tg_id, op.is_active))

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:op:toggle:"))
async def op_toggle(cb: CallbackQuery, session: AsyncSession):
    tg_id = int(cb.data.split(":")[-1])
    dao = OperatorsDAO(session)
    op = await dao.get_by_tg(tg_id)
    if not op:
        await cb.answer("Оператор не найден", show_alert=True)
        return
    op.is_active = not op.is_active
    await session.commit()
    await cb.answer("✅ Готово")
