from aiogram import Router
from aiogram.types import Message

router = Router()

@router.message(lambda m: m.text == "/admin")
async def admin_start(message: Message):
    await message.answer("Админ панель (V1)")