from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from bot.middlewares.role import RoleFilter
from bot.keyboards.inline.admin_warehouses import admin_main_kb

router = Router()

@router.message(RoleFilter("admin"), F.text == "🛠 Админ панель")
async def admin_panel(message: Message):
    await message.answer("🛠 Админ-панель", reply_markup=admin_main_kb())

@router.callback_query(RoleFilter("admin"), F.data == "admin:home")
async def admin_home(cb: CallbackQuery):
    await cb.message.edit_text("🛠 Админ-панель", reply_markup=admin_main_kb())
