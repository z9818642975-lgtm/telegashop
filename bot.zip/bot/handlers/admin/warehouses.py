from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.middlewares.role import RoleFilter
from bot.dao.warehouses_dao import WarehousesDAO
from bot.fsm.admin_fsm import AdminFSM
from bot.keyboards.inline.admin_warehouses import warehouses_list_kb, warehouse_manage_kb

router = Router()

@router.callback_query(RoleFilter("admin"), F.data == "admin:wh:list")
async def wh_list(cb: CallbackQuery, session: AsyncSession):
    dao = WarehousesDAO(session)
    await dao.ensure_central()
    warehouses = await dao.list_active()
    text = "🏬 Склады (активные):\n" + "\n".join([f"#{w.id} {w.title}" for w in warehouses])
    await cb.message.edit_text(text, reply_markup=warehouses_list_kb(warehouses))

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:wh:open:"))
async def wh_open(cb: CallbackQuery, session: AsyncSession):
    wh_id = int(cb.data.split(":")[-1])
    dao = WarehousesDAO(session)
    warehouses = await dao.list_active()
    w = next((x for x in warehouses if x.id == wh_id), None)
    if not w:
        await cb.answer("Склад не найден", show_alert=True)
        return
    text = f"🏬 Склад #{w.id}\nТип: {w.type}\nНазвание: {w.title}\nАдрес: {w.address or '—'}"
    await cb.message.edit_text(text, reply_markup=warehouse_manage_kb(w.id, w.is_active))

@router.callback_query(RoleFilter("admin"), F.data == "admin:wh:create")
async def wh_create(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdminFSM.wh_operator_tg_id)
    await cb.message.edit_text("Введите TG ID оператора для склада (число), либо 0 для центрального:")

@router.message(RoleFilter("admin"), AdminFSM.wh_operator_tg_id)
async def wh_create_step1(message: Message, state: FSMContext):
    try:
        tg_id = int(message.text.strip())
    except Exception:
        await message.answer("Нужно число TG ID.")
        return
    await state.update_data(wh_operator_tg_id=tg_id)
    await state.set_state(AdminFSM.wh_title)
    await message.answer("Введите название склада (например: 'Склад оператора Иван'):")

@router.message(RoleFilter("admin"), AdminFSM.wh_title)
async def wh_create_step2(message: Message, state: FSMContext):
    await state.update_data(wh_title=message.text.strip())
    await state.set_state(AdminFSM.wh_address)
    await message.answer("Введите адрес склада (самовывоз):")

@router.message(RoleFilter("admin"), AdminFSM.wh_address)
async def wh_create_step3(message: Message, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    tg_id = int(data["wh_operator_tg_id"])
    title = data["wh_title"]
    address = message.text.strip()
    dao = WarehousesDAO(session)

    if tg_id == 0:
        # central
        central = await dao.ensure_central()
        await dao.set_address(central.id, address)
    else:
        existing = await dao.get_operator_wh(tg_id)
        if existing:
            await dao.set_address(existing.id, address)
        else:
            await dao.create_operator_wh(tg_id, title, address)
    await session.commit()
    await state.clear()
    await message.answer("✅ Склад сохранён. Откройте '🛠 Админ панель' → '🏬 Склады'.")

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:wh:addr:"))
async def wh_set_addr(cb: CallbackQuery, state: FSMContext):
    wh_id = int(cb.data.split(":")[-1])
    await state.set_state(AdminFSM.wh_set_address)
    await state.update_data(wh_id=wh_id)
    await cb.message.edit_text(f"Введите новый адрес для склада #{wh_id}:")

@router.message(RoleFilter("admin"), AdminFSM.wh_set_address)
async def wh_set_addr_save(message: Message, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    wh_id = int(data["wh_id"])
    addr = message.text.strip()
    dao = WarehousesDAO(session)
    await dao.set_address(wh_id, addr)
    await session.commit()
    await state.clear()
    await message.answer(f"✅ Адрес склада #{wh_id} обновлён.")

@router.callback_query(RoleFilter("admin"), F.data.startswith("admin:wh:toggle:"))
async def wh_toggle(cb: CallbackQuery, session: AsyncSession):
    wh_id = int(cb.data.split(":")[-1])
    dao = WarehousesDAO(session)
    warehouses = await dao.list_active()
    w = next((x for x in warehouses if x.id == wh_id), None)
    # if not in active list, allow toggle by direct update
    new_state = False if w else True
    await dao.set_archive(wh_id, new_state)
    await session.commit()
    await cb.answer("✅ Готово")
