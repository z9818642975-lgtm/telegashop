from aiogram import Router

from .start import router as start_router
from .panel_v1 import router as panel_router
from .warehouses import router as warehouses_router
from .operators import router as operators_router
from .transfers import router as transfers_router
from .stocks import router as stocks_router

router = Router(name="admin")
router.include_router(start_router)
router.include_router(panel_router)
router.include_router(warehouses_router)
router.include_router(operators_router)
router.include_router(transfers_router)
router.include_router(stocks_router)
