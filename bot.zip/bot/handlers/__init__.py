# -*- coding: utf-8 -*-
# bot/handlers/__init__.py
# IMPORTANT: keep empty to avoid side-imports and double router attach
