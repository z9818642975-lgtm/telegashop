from aiogram import Router, F
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import CallbackQuery
from bot.keyboards.inline.banks import banks_kb
from bot.keyboards.inline.confirm import confirm_kb

router = Router()

class OrderFSM(StatesGroup):
    choose_bank = State()
    confirm = State()

@router.callback_query(F.data.startswith("bank:"))
async def choose_bank(cb: CallbackQuery, state):
    await state.update_data(bank=cb.data.split(":")[1])
    await cb.message.edit_text("Подтвердите оплату", reply_markup=confirm_kb())
    await state.set_state(OrderFSM.confirm)

@router.callback_query(F.data == "paid")
async def paid(cb: CallbackQuery, state):
    await cb.message.answer("Заказ создан, ожидайте оператора")
    await state.clear()