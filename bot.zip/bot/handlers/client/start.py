# -*- coding: utf-8 -*-
from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from bot.keyboards.reply.client_menu import client_menu_kb

router = Router(name="client_start")


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    await message.answer(
        "Добро пожаловать! Выберите раздел 👇",
        reply_markup=client_menu_kb(),
    )
