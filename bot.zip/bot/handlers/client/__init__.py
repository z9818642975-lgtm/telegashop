# -*- coding: utf-8 -*-
"""Client routers.

ВАЖНО:
- /start обрабатывается единым роутером: bot.handlers.common.start
- Здесь подключаем только клиентское меню и inline-FSM заказа.
"""

from aiogram import Router

from .menu import router as menu_router
from .order_fsm import router as order_fsm_router


router = Router(name="client")

router.include_router(menu_router)
router.include_router(order_fsm_router)
