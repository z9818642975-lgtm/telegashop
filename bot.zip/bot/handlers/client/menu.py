# -*- coding: utf-8 -*-
# ============================================================
# bot/handlers/client/menu.py — Client main menu handlers (V1)
# ============================================================

from __future__ import annotations

from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from bot.states.order import OrderFSM
from bot.keyboards.reply.client_menu import client_main_menu
from bot.keyboards.inline.catalog import catalog_kb

router = Router(name="client_menu")


@router.message(F.text == "📦 Каталог")
async def open_catalog(message: Message, state: FSMContext) -> None:
    # стартуем цикл добавления товаров
    await state.set_state(OrderFSM.product)
    data = await state.get_data()
    if "items" not in data:
        await state.update_data(items={})

    await message.answer(
        "📦 Выберите товар (можно добавить несколько позиций).\n"
        "После выбора количества бот вернёт вас обратно в каталог.\n"
        "Когда готовы — нажмите «✅ Оформить».",
        reply_markup=catalog_kb(),
    )


@router.message(F.text == "🧺 Корзина")
async def open_cart(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    items = data.get("items") or {}
    if not items:
        await message.answer("🧺 Корзина пуста. Откройте «📦 Каталог».", reply_markup=client_main_menu())
        return

    # показываем кратко
    lines = ["🧺 Корзина:"]
    for name, qty in dict(items).items():
        lines.append(f"• {name} — {qty} шт")
    lines.append("\nОткройте «📦 Каталог», чтобы продолжить и нажать «✅ Оформить».")
    await message.answer("\n".join(lines), reply_markup=client_main_menu())


@router.message(F.text == "👤 Профиль")
async def open_profile(message: Message) -> None:
    await message.answer(
        "👤 Профиль (V1): будет добавлено дальше.",
        reply_markup=client_main_menu(),
    )


@router.message(F.text == "❓ FAQ")
async def open_faq(message: Message) -> None:
    await message.answer(
        "❓ FAQ (V1): будет добавлено дальше.",
        reply_markup=client_main_menu(),
    )


@router.message(F.text == "💬 Связь с оператором")
async def open_support(message: Message) -> None:
    await message.answer(
        "💬 Связь с оператором (V1): будет подключено дальше.",
        reply_markup=client_main_menu(),
    )
