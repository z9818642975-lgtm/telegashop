from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from bot.fsm.order import OrderFSM
from bot.keyboards.inline.products import products_kb
from bot.keyboards.inline.quantity import quantity_kb
from bot.keyboards.inline.delivery import delivery_kb
from bot.keyboards.inline.banks import banks_kb
from bot.keyboards.inline.payment_confirm import payment_confirm_kb

router = Router()

PRICES = {
    "meow": 3500,
    "coke": 11000,
    "gash": 1800,
}

# START
@router.message(F.text == "📦 Каталог")
async def start_order(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(OrderFSM.product)
    await state.update_data(cart={})
    await message.answer("Выберите товар:", reply_markup=products_kb())


# PRODUCT
@router.callback_query(F.data.startswith("product:"))
async def product_select(call: CallbackQuery, state: FSMContext):
    action = call.data.split(":")[1]
    if action == "done":
        await state.set_state(OrderFSM.delivery_type)
        await call.message.edit_text("Способ получения:", reply_markup=delivery_kb())
        return

    await state.update_data(current_product=action)
    await state.set_state(OrderFSM.quantity)
    await call.message.edit_text("Выберите количество:", reply_markup=quantity_kb())


# QUANTITY
@router.callback_query(F.data.startswith("qty:"))
async def quantity_select(call: CallbackQuery, state: FSMContext):
    qty = int(call.data.split(":")[1])
    data = await state.get_data()

    cart = data["cart"]
    product = data["current_product"]
    cart[product] = cart.get(product, 0) + qty

    await state.update_data(cart=cart)
    await state.set_state(OrderFSM.product)
    await call.message.edit_text("Товар добавлен. Можно выбрать ещё:", reply_markup=products_kb())


# DELIVERY
@router.callback_query(F.data.startswith("delivery:"))
async def delivery_select(call: CallbackQuery, state: FSMContext):
    dtype = call.data.split(":")[1]
    await state.update_data(delivery=dtype)

    if dtype == "delivery":
        await state.set_state(OrderFSM.address)
        await call.message.edit_text("Введите адрес доставки:")
    else:
        await state.set_state(OrderFSM.bank)
        await call.message.edit_text("Выберите банк:", reply_markup=banks_kb())


# ADDRESS
@router.message(OrderFSM.address)
async def address_input(message: Message, state: FSMContext):
    await state.update_data(address=message.text)
    await state.set_state(OrderFSM.bank)
    await message.answer("Выберите банк:", reply_markup=banks_kb())


# BANK
@router.callback_query(F.data.startswith("bank:"))
async def bank_select(call: CallbackQuery, state: FSMContext):
    bank = call.data.split(":")[1]
    data = await state.get_data()

    total = sum(PRICES[p] * q for p, q in data["cart"].items())
    await state.update_data(bank=bank, total=total)

    text = f"💰 Сумма: {total} ₽\n\nОтправьте чек (скрин / PDF)"
    await state.set_state(OrderFSM.payment_proof)
    await call.message.edit_text(text, reply_markup=payment_confirm_kb())
