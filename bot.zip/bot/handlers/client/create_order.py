from aiogram import Router, F
from aiogram.types import CallbackQuery
from bot.models.order import Order
from bot.services.order_price import calc_total

router = Router()

@router.callback_query(F.data == "paid")
async def create_order(cb: CallbackQuery, state, session):
    data = await state.get_data()
    total = calc_total(data["product"], data["quantity"], data["delivery_price"])

    order = Order(
        user_id=cb.from_user.id,
        product=data["product"],
        quantity=data["quantity"],
        delivery=data["delivery"],
        delivery_price=data["delivery_price"],
        bank=data["bank"],
        total_price=total,
    )
    session.add(order)
    await session.commit()

    await cb.message.answer(f"✅ Заказ создан\nСумма: {total} ₽")
    await state.clear()