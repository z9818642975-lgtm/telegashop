from bot.keyboards.inline.operator_check import operator_check_kb
from bot.services.notify_service import NotifyService

from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

router = Router()

@router.message(F.content_type.in_({"photo","document"}))
async def receive_check(message: Message, state: FSMContext):
    await message.answer("✅ Чек получен, ожидайте подтверждения оператора")
