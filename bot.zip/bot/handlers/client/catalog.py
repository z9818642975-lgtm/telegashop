from aiogram import Router, types
from aiogram.filters import CommandStart
from sqlalchemy import select
from bot.core.db import async_session_maker
from bot.models.product import Product

router = Router()

@router.message(CommandStart())
async def catalog(message: types.Message):
    async with async_session_maker() as session:
        result = await session.execute(select(Product).where(Product.is_active.is_(True)))
        products = result.scalars().all()

    if not products:
        await message.answer("📦 Каталог пуст")
        return

    text = "📦 Каталог:\n"
    for p in products:
        text += f"• {p.title} — {p.base_price} ₽\n"

    await message.answer(text)
