from aiogram import Router
from aiogram.types import CallbackQuery, Message
from bot.states.cart_states import CartFSM
from bot.keyboards.inline.quantity_inline import quantity_kb
from aiogram.fsm.context import FSMContext

router = Router()

@router.message(lambda m: m.text == "🧺 Корзина")
async def cart_start(message: Message, state: FSMContext):
    await state.set_state(CartFSM.choosing_quantity)
    await message.answer("Выбери количество:", reply_markup=quantity_kb())

@router.callback_query(lambda c: c.data.startswith("qty:"))
async def choose_qty(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer("✅ Заказ создан (демо)")
    await call.answer()