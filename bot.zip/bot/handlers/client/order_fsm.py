# -*- coding: utf-8 -*-
# ============================================================
# bot/handlers/client/order_fsm.py — Inline FSM заказа (V1, cart loop)
# ============================================================

from __future__ import annotations

import json
from urllib.parse import quote_plus

from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from bot.states.order import OrderFSM
from bot.keyboards.inline import quantity, delivery, delivery_price, banks, pay
from bot.keyboards.inline.catalog import catalog_kb
from bot.dao.users_dao import UsersDAO
from bot.dao.shifts_dao import OperatorShiftDAO
from bot.core.bank_requisites import render_requisites
from bot.models.order import Order

router = Router(name="client_order_fsm_v1")


BASE_PRICES = {
    "мяу": 3500,
    "кок": 11000,
    "бош": 1800,
    "гар": 1800,
    "экс": 1600,
    "лир": 4000,
}


def _items_summary(items: dict[str, int]) -> str:
    if not items:
        return "—"
    lines = []
    for name, qty in items.items():
        lines.append(f"{name} — {qty} шт")
    return "\n".join(lines)


def _calc_total(items: dict[str, int], delivery_price_value: int) -> int:
    total = 0
    for name, qty in items.items():
        total += BASE_PRICES.get(name.lower(), 0) * int(qty)
    total += int(delivery_price_value or 0)
    return total


def _address_kb():
    # минимальный back
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="addr:back")]
    ])


@router.callback_query(OrderFSM.product, F.data.startswith("prod:"))
async def pick_product(cb: CallbackQuery, state: FSMContext) -> None:
    product = cb.data.split(":", 1)[1].strip().lower()
    await state.set_state(OrderFSM.quantity)
    await state.update_data(tmp_product=product)

    await cb.message.edit_text(
        f"Товар: <b>{product}</b>\nВыберите количество:",
        reply_markup=quantity.quantity_kb(),
    )
    await cb.answer()


@router.callback_query(OrderFSM.quantity, F.data.startswith("qty:"))
async def pick_quantity(cb: CallbackQuery, state: FSMContext) -> None:
    qty = int(cb.data.split(":", 1)[1])

    data = await state.get_data()
    items = dict(data.get("items") or {})
    product = (data.get("tmp_product") or "").strip().lower()

    if not product:
        await cb.answer("Сначала выберите товар", show_alert=True)
        await state.set_state(OrderFSM.product)
        await cb.message.edit_text("📦 Выберите товар:", reply_markup=catalog_kb())
        return

    # ✅ суммируем одинаковые товары
    items[product] = int(items.get(product, 0)) + qty

    await state.update_data(items=items, tmp_product=None)

    # ✅ по ТЗ: после выбора количества возвращаемся к выбору товара
    await state.set_state(OrderFSM.product)

    await cb.message.edit_text(
        "🧺 Текущая корзина:\n"
        f"{_items_summary(items)}\n\n"
        "Добавьте ещё товар или нажмите «✅ Оформить».",
        reply_markup=catalog_kb(),
    )
    await cb.answer("Добавлено ✅")


@router.callback_query(OrderFSM.product, F.data == "cart:clear")
async def cart_clear(cb: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(items={})
    await cb.message.edit_text(
        "🧹 Корзина очищена.\n\n📦 Выберите товар:",
        reply_markup=catalog_kb(),
    )
    await cb.answer()


@router.callback_query(OrderFSM.product, F.data == "cart:checkout")
async def cart_checkout(cb: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    items = dict(data.get("items") or {})
    if not items:
        await cb.answer("Корзина пуста", show_alert=True)
        return

    await state.set_state(OrderFSM.delivery)
    await cb.message.edit_text(
        "✅ Оформление заказа\n\n"
        "🧺 Корзина:\n"
        f"{_items_summary(items)}\n\n"
        "Выберите способ получения:",
        reply_markup=delivery.delivery_kb(),
    )
    await cb.answer()


@router.callback_query(OrderFSM.delivery, F.data.startswith("delivery:"))
async def pick_delivery(cb: CallbackQuery, state: FSMContext) -> None:
    d = cb.data.split(":", 1)[1]
    await state.update_data(delivery=d)

    if d == "delivery":
        await state.set_state(OrderFSM.address)
        await cb.message.edit_text(
            "📍 Введите адрес доставки <b>сообщением</b>.",
            reply_markup=_address_kb(),
        )
        await cb.answer()
        return

    # Самовывоз → доставка 0 и сразу к банку
    await state.update_data(address="самовывоз", delivery_price=0)
    await state.set_state(OrderFSM.bank)

    data = await state.get_data()
    items = dict(data.get("items") or {})
    total = _calc_total(items, 0)

    await cb.message.edit_text(
        f"Самовывоз выбран.\nСумма к оплате: <b>{total} ₽</b>\n\nВыберите банк/способ оплаты:",
        reply_markup=banks.banks_kb(),
    )
    await cb.answer()


@router.callback_query(OrderFSM.address, F.data == "addr:back")
async def addr_back(cb: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(OrderFSM.delivery)
    await cb.message.edit_text(
        "Выберите способ получения:",
        reply_markup=delivery.delivery_kb(),
    )
    await cb.answer()


@router.message(OrderFSM.address)
async def address_entered(message: Message, state: FSMContext) -> None:
    address = (message.text or "").strip()
    if len(address) < 5:
        await message.answer("Адрес слишком короткий. Введите адрес доставки полностью.")
        return

    await state.update_data(address=address)
    await state.set_state(OrderFSM.delivery_price)

    await message.answer(
        "Выберите стоимость доставки:",
        reply_markup=delivery_price.delivery_price_kb(),
    )


@router.callback_query(OrderFSM.delivery_price, F.data.startswith("delprice:"))
async def pick_delivery_price(cb: CallbackQuery, state: FSMContext) -> None:
    price = int(cb.data.split(":", 1)[1])
    await state.update_data(delivery_price=price)
    await state.set_state(OrderFSM.bank)

    data = await state.get_data()
    items = dict(data.get("items") or {})
    total = _calc_total(items, price)

    await cb.message.edit_text(
        f"Сумма к оплате: <b>{total} ₽</b>\n\nВыберите банк/способ оплаты:",
        reply_markup=banks.banks_kb(),
    )
    await cb.answer()


@router.callback_query(OrderFSM.bank, F.data.startswith("bank:"))
async def pick_bank(cb: CallbackQuery, state: FSMContext) -> None:
    bank_code = cb.data.split(":", 1)[1]
    await state.update_data(bank=bank_code)
    await state.set_state(OrderFSM.confirm)

    data = await state.get_data()
    items = dict(data.get("items") or {})
    del_price = int(data.get("delivery_price") or 0)
    total = _calc_total(items, del_price)

    requisites = render_requisites(bank_code)
    await cb.message.edit_text(
        "<b>Оплата</b>\n\n"
        f"{requisites}\n\n"
        f"Сумма: <b>{total} ₽</b>\n\n"
        "Переведите сумму по реквизитам выше, затем нажмите «✅ Я оплатил».",
        reply_markup=pay.pay_kb(),
    )
    await cb.answer()


@router.callback_query(OrderFSM.confirm, F.data == "pay:done")
async def pay_done(cb: CallbackQuery, state: FSMContext, session: AsyncSession) -> None:
    data = await state.get_data()
    items = dict(data.get("items") or {})
    delivery_type = data.get("delivery") or "pickup"
    address = data.get("address") or "—"
    del_price = int(data.get("delivery_price") or 0)
    bank_code = data.get("bank") or "—"

    total = _calc_total(items, del_price)

    # ✅ создаём заказ в БД
    comment_lines = [f"{name} - {qty} шт" for name, qty in items.items()]
    if delivery_type == "delivery":
        # ссылка на карты
        maps = f"https://yandex.ru/maps/?text={quote_plus(str(address))}"
        comment_lines.append(f"Адрес доставки: {address} ({maps})")
    else:
        comment_lines.append("Самовывоз")

    comment_text = "\n".join(comment_lines)

    order = Order(
        user_id=cb.from_user.id,
        product="multi",
        quantity=sum(int(x) for x in items.values()) if items else 1,
        delivery=delivery_type,
        delivery_price=del_price,
        bank=bank_code,
        total_price=total,
        status="PAID",       # клиент нажал «я оплатил»
        is_paid=False,       # оператор подтвердит
        comment=comment_text,
        items_json=json.dumps(cart_items),
        address=str(address) if address else None,
    )
    session.add(order)
    await session.commit()
    await session.refresh(order)

    # ✅ уведомление операторам
    users = UsersDAO(session)
    ops = await users.get_active_operators()
    if ops:
        from bot.keyboards.inline.operator_orders_v1 import order_actions_kb
        text = (
            f"Заказ №{order.id}\n"
            + "\n".join([f"{name} - {qty} шт" for name, qty in items.items()])
            + ("\nСамовывоз" if delivery_type != "delivery" else f"\nАдрес доставки: {address}")
        )
        for op in ops:
            try:
                await cb.bot.send_message(op.tg_id, text, reply_markup=order_actions_kb(order))
            except Exception:
                pass

    await cb.message.edit_text(
        "✅ Принято!\n"
        "Мы получили подтверждение оплаты и передали заказ оператору.\n\n"
        f"Итог: <b>{total} ₽</b>",
        reply_markup=None,
    )
    await state.clear()
    await cb.answer()


@router.callback_query(OrderFSM.confirm, F.data == "pay:cancel")
async def pay_cancel(cb: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await cb.message.edit_text("❌ Заказ отменён.", reply_markup=None)
    await cb.answer()
