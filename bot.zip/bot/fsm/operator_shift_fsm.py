from aiogram.fsm.state import StatesGroup, State

class OperatorShiftFSM(StatesGroup):
    wait_address = State()
