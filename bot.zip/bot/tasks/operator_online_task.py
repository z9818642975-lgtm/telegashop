# ============================================================
# bot/tasks/operator_online_task.py
# ============================================================

import asyncio

from bot.core.db import async_session_maker
from bot.services.operator_online_service import OperatorOnlineService
from bot.core.logger import logger


async def run_online_task(bot):
    """
    Фоновая задача:
    проверяет онлайн операторов и их смены
    """

    logger.info("🟢 Operator online task started")

    while True:
        try:
            async with async_session_maker() as session:
                service = OperatorOnlineService(session)
                await service.run(bot)

        except Exception as e:
            logger.exception("❌ online task error: %s", e)

        await asyncio.sleep(30)
