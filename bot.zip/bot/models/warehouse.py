# ============================================================
# bot/models/warehouse.py
# ============================================================
from __future__ import annotations

from sqlalchemy import Integer, BigInteger, String, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from bot.core.db import Base


class Warehouse(Base):
    __tablename__ = "warehouses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    # CENTRAL / OPERATOR
    type: Mapped[str] = mapped_column(String, nullable=False)

    # for operator warehouse: owner_id = operator tg_id
    owner_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    # human readable name
    title: Mapped[str] = mapped_column(String, nullable=False)

    # pickup address (for operator this is self-pickup address)
    address: Mapped[str | None] = mapped_column(String, nullable=True)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
