# ============================================================
# bot/models/restock_order.py
# ============================================================

from __future__ import annotations

from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func

from bot.core.db import Base


class RestockOrder(Base):
    __tablename__ = "restock_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    product_id: Mapped[int] = mapped_column(Integer, nullable=False)
    warehouse_id: Mapped[int] = mapped_column(Integer, nullable=False)

    qty: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False)

    created_at: Mapped = mapped_column(DateTime, server_default=func.now())
