# ============================================================
# bot/models/operator.py
# ============================================================
from __future__ import annotations

from sqlalchemy import Integer, BigInteger, String, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from bot.core.db import Base


class Operator(Base):
    __tablename__ = "operators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String, nullable=False, default="Оператор")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
