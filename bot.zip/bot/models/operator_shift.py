# ============================================================
# bot/models/operator_shift.py
# ============================================================

from datetime import datetime

from sqlalchemy import Integer, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column

from bot.core.db import Base


class OperatorShift(Base):
    __tablename__ = "operator_shifts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    operator_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("users.id"),
        nullable=False,
    )

    pickup_address: Mapped[str] = mapped_column(Text, nullable=False)

    started_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )
    ended_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    auto_closed: Mapped[bool] = mapped_column(Boolean, default=False)
