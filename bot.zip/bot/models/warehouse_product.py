# -*- coding: utf-8 -*-
# ============================================================
# bot/models/warehouse_product.py
# ============================================================
from __future__ import annotations

from sqlalchemy import Integer, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from bot.core.db import Base


class WarehouseProduct(Base):
    """Связка склад ↔ товар с остатками"""
    __tablename__ = "warehouse_products"

    warehouse_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("warehouses.id", ondelete="CASCADE"),
        primary_key=True,
    )
    product_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("products.id", ondelete="CASCADE"),
        primary_key=True,
    )

    qty_available: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    low_notified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
