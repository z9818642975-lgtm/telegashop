# ============================================================
# bot/models/warehouse_transfer.py
# ============================================================
from __future__ import annotations

from datetime import datetime
from sqlalchemy import Integer, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from bot.core.db import Base


class WarehouseTransfer(Base):
    __tablename__ = "warehouse_transfers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    from_warehouse_id: Mapped[int] = mapped_column(Integer, nullable=False)
    to_warehouse_id: Mapped[int] = mapped_column(Integer, nullable=False)
    product_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)

    created_by: Mapped[int] = mapped_column(Integer, nullable=False)  # admin tg_id
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
