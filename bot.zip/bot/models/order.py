from sqlalchemy import Integer, String, Boolean, Text, BigInteger
from sqlalchemy.orm import Mapped, mapped_column
from bot.core.db import Base

class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(primary_key=True)

    user_id: Mapped[int] = mapped_column(BigInteger, nullable=False)

    # legacy (оставлено для совместимости)
    product: Mapped[str] = mapped_column(String, default="multi")
    quantity: Mapped[int] = mapped_column(Integer, default=1)

    delivery: Mapped[str] = mapped_column(String, default="pickup")
    address: Mapped[str | None] = mapped_column(Text, nullable=True)

    delivery_price: Mapped[int] = mapped_column(Integer, default=0)
    bank: Mapped[str] = mapped_column(String, default="—")

    total_price: Mapped[int] = mapped_column(Integer, default=0)

    # ✅ для операторского флоу V1
    status: Mapped[str] = mapped_column(String, default="NEW")
    is_paid: Mapped[bool] = mapped_column(Boolean, default=False)

    # позиции и служебный текст
    items_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
