class RestockService:
    pass
