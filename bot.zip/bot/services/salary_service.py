def calc_salary(amount: int) -> int:
    return int(amount * 0.2)