class ForecastService:
    pass
