PRICES = {
    "мяу": 3500,
    "кок": 11000,
    "гаш": 1800,
    "бош": 1800,
    "экс": 1600,
    "лир": 4000,
}

def calc_total(product: str, qty: int, delivery_price: int):
    return PRICES[product] * qty + delivery_price