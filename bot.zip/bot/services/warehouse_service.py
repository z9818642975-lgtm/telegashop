from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from bot.dao.warehouses_dao import WarehousesDAO
from bot.dao.warehouse_products_dao import WarehouseProductsDAO
from bot.dao.transfers_dao import TransfersDAO


class WarehouseService:
    def __init__(self, session: AsyncSession):
        self.s = session
        self.wh = WarehousesDAO(session)
        self.wp = WarehouseProductsDAO(session)
        self.tr = TransfersDAO(session)

    async def ensure_central(self):
        return await self.wh.ensure_central()

    async def get_operator_wh_or_raise(self, operator_tg_id: int):
        wh = await self.wh.get_operator_wh(operator_tg_id)
        if not wh:
            raise ValueError("У оператора нет склада (нет адреса самовывоза).")
        return wh

    async def check_has_stock(self, warehouse_id: int, product_id: int, qty: int) -> bool:
        have = await self.wp.get_qty(warehouse_id, product_id)
        return have >= qty

    async def require_has_stock(self, warehouse_id: int, product_id: int, qty: int):
        if not await self.check_has_stock(warehouse_id, product_id, qty):
            have = await self.wp.get_qty(warehouse_id, product_id)
            raise ValueError(f"Недостаточно товара на складе (product_id={product_id}). Нужно {qty}, есть {have}.")

    async def deduct_from_operator_for_client(self, operator_tg_id: int, product_id: int, qty: int):
        wh = await self.get_operator_wh_or_raise(operator_tg_id)
        # move stock from operator warehouse to nowhere (client)
        await self.wp.move(wh.id, wh.id, product_id, 0)  # no-op to ensure row exists
        row = await self.wp.get_row(wh.id, product_id)
        if not row or row.qty_available < qty:
            have = row.qty_available if row else 0
            raise ValueError(f"Недостаточно товара у оператора. Нужно {qty}, есть {have}.")
        row.qty_available -= qty

    async def admin_add_stock(self, warehouse_id: int, product_id: int, qty: int, admin_tg_id: int):
        await self.wp.add(warehouse_id, product_id, qty)
        await self.tr.log(warehouse_id, warehouse_id, product_id, qty, admin_tg_id)

    async def admin_move_stock(self, from_wh: int, to_wh: int, product_id: int, qty: int, admin_tg_id: int):
        # only admin is allowed to move CENTRAL->OPERATOR
        await self.wp.move(from_wh, to_wh, product_id, qty)
        await self.tr.log(from_wh, to_wh, product_id, qty, admin_tg_id)
