# ============================================================
# bot/dao/users_dao.py
# ============================================================

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models.user import User, UserRole


class UsersDAO:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_tg_id(self, tg_id: int) -> User | None:
        result = await self.session.execute(
            select(User).where(User.tg_id == tg_id)
        )
        return result.scalar_one_or_none()

    async def create(
        self,
        *,
        tg_id: int,
        username: str | None = None,
        full_name: str | None = None,
        role: UserRole = UserRole.CLIENT,
        is_active: bool = True,
    ) -> User:
        user = User(
            tg_id=tg_id,
            username=username,
            full_name=full_name,
            role=role,
            is_active=is_active,
        )
        self.session.add(user)
        await self.session.flush()
        return user

    async def get_active_operators(self) -> list[User]:
        result = await self.session.execute(
            select(User).where(
                User.role == UserRole.OPERATOR,
                User.is_active.is_(True),
            )
        )
        return result.scalars().all()
