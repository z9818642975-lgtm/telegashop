# ============================================================
# bot/dao/shifts_dao.py
# ============================================================

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models.operator_shift import OperatorShift


class OperatorShiftDAO:
    def __init__(self, session: AsyncSession):
        self.s = session

    async def get_active(self, operator_id: int) -> OperatorShift | None:
        """
        Возвращает активную смену оператора (ended_at IS NULL)
        operator_id = users.id
        """
        res = await self.s.execute(
            select(OperatorShift).where(
                OperatorShift.operator_id == operator_id,
                OperatorShift.ended_at.is_(None),
            )
        )
        return res.scalars().first()

    async def start(
        self,
        operator_id: int,
        pickup_address: str,
    ) -> OperatorShift:
        """
        Старт смены оператора
        """
        shift = OperatorShift(
            operator_id=operator_id,
            pickup_address=pickup_address,
        )
        self.s.add(shift)
        await self.s.flush()
        return shift

    async def end(
        self,
        shift_id: int,
        auto_closed: bool = False,
    ) -> None:
        """
        Завершение смены
        """
        res = await self.s.execute(
            select(OperatorShift).where(OperatorShift.id == shift_id)
        )
        shift = res.scalars().first()
        if not shift:
            return

        shift.ended_at = shift.ended_at or shift.started_at
        shift.auto_closed = auto_closed
