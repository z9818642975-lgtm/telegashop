from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from bot.models.warehouse import Warehouse


class WarehousesDAO:
    def __init__(self, s: AsyncSession):
        self.s = s

    async def get_central(self) -> Warehouse | None:
        res = await self.s.execute(select(Warehouse).where(Warehouse.type == "CENTRAL", Warehouse.is_active.is_(True)))
        return res.scalar_one_or_none()

    async def ensure_central(self) -> Warehouse:
        wh = await self.get_central()
        if wh:
            return wh
        wh = Warehouse(type="CENTRAL", owner_id=None, title="🏭 Центральный склад", address=None, is_active=True)
        self.s.add(wh)
        await self.s.flush()
        return wh

    async def get_operator_wh(self, operator_tg_id: int) -> Warehouse | None:
        res = await self.s.execute(
            select(Warehouse).where(
                Warehouse.type == "OPERATOR",
                Warehouse.owner_id == operator_tg_id,
                Warehouse.is_active.is_(True),
            )
        )
        return res.scalar_one_or_none()

    async def create_operator_wh(self, operator_tg_id: int, title: str, address: str) -> Warehouse:
        wh = Warehouse(type="OPERATOR", owner_id=operator_tg_id, title=title, address=address, is_active=True)
        self.s.add(wh)
        await self.s.flush()
        return wh

    async def list_active(self) -> list[Warehouse]:
        res = await self.s.execute(select(Warehouse).where(Warehouse.is_active.is_(True)).order_by(Warehouse.id.asc()))
        return list(res.scalars().all())

    async def set_archive(self, warehouse_id: int, active: bool) -> None:
        await self.s.execute(update(Warehouse).where(Warehouse.id == warehouse_id).values(is_active=active))

    async def set_address(self, warehouse_id: int, address: str) -> None:
        await self.s.execute(update(Warehouse).where(Warehouse.id == warehouse_id).values(address=address))
