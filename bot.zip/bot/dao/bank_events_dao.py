from sqlalchemy.ext.asyncio import AsyncSession
from bot.models.bank_event import BankEvent


class BankEventsDAO:
    def __init__(self, s: AsyncSession):
        self.s = s

    async def add(self, **kwargs):
        self.s.add(BankEvent(**kwargs))
        await self.s.flush()
