class ChatsDAO:
    pass
