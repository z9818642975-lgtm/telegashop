import asyncio
import bot.models  # noqa: F401

from bot.core.db import async_session_maker

# ⚠️ ВАЖНО: принудительно регистрируем ВСЕ модели

from bot.models.product import Product


PRODUCTS = [
    {
        "sku": "MEOW",
        "title": "Мяу",
        "base_price": 3500,
        "min_qty": 1,
        "is_active": True,
    },
    {
        "sku": "KOK",
        "title": "Кок",
        "base_price": 11000,
        "min_qty": 1,
        "is_active": True,
    },
    {
        "sku": "HASH",
        "title": "Гаш",
        "base_price": 1800,
        "min_qty": 2,
        "is_active": True,
    },
    {
        "sku": "BOSH",
        "title": "Бош",
        "base_price": 1800,
        "min_qty": 2,
        "is_active": True,
    },
    {
        "sku": "EX",
        "title": "Экс",
        "base_price": 1600,
        "min_qty": 2,
        "is_active": True,
    },
    {
        "sku": "LIR",
        "title": "Лир",
        "base_price": 4000,
        "min_qty": 1,
        "is_active": True,
    },
]



async def main():
    async with async_session_maker() as session:
        for data in PRODUCTS:
            exists = await session.execute(
                Product.__table__.select().where(Product.sku == data["sku"])
            )
            if exists.first():
                continue

            session.add(Product(**data))

        await session.commit()
        print("✅ Products seeded")


if __name__ == "__main__":
    asyncio.run(main())
