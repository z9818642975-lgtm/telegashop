from __future__ import annotations

from aiogram.types import TelegramObject
from aiogram import BaseMiddleware
from aiogram.dispatcher.flags import get_flag
from aiogram.fsm.context import FSMContext
from typing import Any, Awaitable, Callable

from sqlalchemy.ext.asyncio import AsyncSession

from bot.core.config import settings
from bot.dao.operators_dao import OperatorsDAO


class RoleMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # try read user
        user = getattr(event, "from_user", None)
        if user is None:
            return await handler(event, data)

        tg_id = user.id

        role = "client"
        if tg_id in settings.ADMINS:
            role = "admin"
        else:
            # DB-based operators (preferred)
            session: AsyncSession | None = data.get("session")
            if session is not None:
                dao = OperatorsDAO(session)
                op = await dao.get_by_tg(tg_id)
                if op and op.is_active:
                    role = "operator"
            # fallback env list
            if role == "client" and tg_id in getattr(settings, "OPERATORS", []):
                role = "operator"

        data["role"] = role
        return await handler(event, data)


class RoleFilter:
    def __init__(self, required_role: str):
        self.required_role = required_role

    async def __call__(self, obj: TelegramObject, data: dict[str, Any]) -> bool:
        return data.get("role") == self.required_role
