from typing import Callable, Awaitable, Dict, Any
from aiogram import BaseMiddleware
from bot.core.db import async_session_maker

class DbSessionMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: Dict[str, Any],
    ) -> Any:
        async with async_session_maker() as session:
            data["session"] = session
            result = await handler(event, data)
            await session.commit()
            return result
