# -*- coding: utf-8 -*-
# ============================================================
# bot/main.py — FINAL STABLE ENTRYPOINT
# ============================================================

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties

from bot.core.config import settings
from bot.core.logger import logger
from bot.core.init_db import init_db

from bot.web.health import run_health_server
from bot.tasks.operator_online_task import run_online_task

from bot.handlers.client import router as client_router
from bot.handlers.operator import router as operator_router
from bot.handlers.admin import router as admin_router
from bot.handlers.common import router as common_router


from bot.middlewares.db import DbSessionMiddleware
from bot.middlewares.role import RoleMiddleware

async def main() -> None:
    bot = Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode="HTML"),
    )
# 1️⃣ Bot и Dispatcher
    dp = Dispatcher()
    # Role — ВАЖНО: только на message/callback (Update не имеет from_user)
    dp.message.middleware(RoleMiddleware())
    dp.callback_query.middleware(RoleMiddleware())
    dp.update.middleware(RoleMiddleware())
    dp.update.middleware(DbSessionMiddleware())


    # 3️⃣ Routers
    # /start — единый роутер по роли
    dp.include_router(common_router)
    dp.include_router(client_router)
    dp.include_router(operator_router)
    dp.include_router(admin_router)

    # 4️⃣ Инициализация БД (create_all, без Alembic)
    logger.info("🧩 Creating DB schema (SQLAlchemy create_all)...")
    await init_db()
    logger.info("✅ DB schema is ready")

    # 5️⃣ Health server (ТОЛЬКО background)
    asyncio.create_task(
        run_health_server(settings.HEALTH_PORT)
    )

    # 6️⃣ Online task операторов (background)
    asyncio.create_task(
        run_online_task(bot)
    )

    logger.info("🚀 TelegaShop FINAL PROD FULL started")

    # 7️⃣ Polling (blocking)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
