from aiogram.fsm.state import StatesGroup, State

class CartFSM(StatesGroup):
    choosing_product = State()
    choosing_quantity = State()
    confirm = State()