from aiogram.fsm.state import StatesGroup, State

class OrderFSM(StatesGroup):
    # добавление товаров (циклом)
    product = State()
    quantity = State()

    # оформление
    delivery = State()
    address = State()          # только если delivery=delivery
    delivery_price = State()
    bank = State()
    confirm = State()
