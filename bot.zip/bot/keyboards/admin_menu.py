from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

admin_main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📊 Общая статистика")],
        [KeyboardButton(text="🧑‍💼 Операторы")],
        [KeyboardButton(text="📦 Склады")],
        [KeyboardButton(text="⚙️ Настройки")],
    ],
    resize_keyboard=True
)
