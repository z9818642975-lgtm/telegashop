from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

operator_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🟢 Начать смену")],
        [KeyboardButton(text="📥 Заказы")],
        [KeyboardButton(text="📊 Статистика")],
    ],
    resize_keyboard=True,
)
