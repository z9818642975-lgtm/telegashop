from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def operator_main_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🟢 Начать смену")],
            [KeyboardButton(text="📦 Заказы")],
            [KeyboardButton(text="📦 Склад")],
            [KeyboardButton(text="📊 Зарплата и статистика")],
            [KeyboardButton(text="🔚 Завершить смену")],
        ],
        resize_keyboard=True,
    )

