from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def admin_main_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📦 Товары")],
            [KeyboardButton(text="👥 Операторы")],
            [KeyboardButton(text="📊 Статистика")],
        ],
        resize_keyboard=True,
    )
