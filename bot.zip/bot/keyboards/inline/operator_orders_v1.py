# -*- coding: utf-8 -*-
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from bot.models.order import Order


def orders_list_kb(orders: list[Order]) -> InlineKeyboardMarkup:
    rows = []
    for o in orders:
        rows.append(
            [InlineKeyboardButton(text=f"#{o.id} • {o.status} • {o.total_price}₽", callback_data=f"op:open:{o.id}")]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def order_actions_kb(order: Order) -> InlineKeyboardMarkup:
    rows = []

    if order.status == "PAID":
        rows.append([InlineKeyboardButton(text="✅ Принять", callback_data=f"op:accept:{order.id}")])

    if order.status in ("IN_WORK", "PAID"):
        rows.append([InlineKeyboardButton(text="💰 Оплатили", callback_data=f"op:paid:{order.id}")])

    if order.status in ("IN_WORK", "PAID_CONFIRMED"):
        rows.append([InlineKeyboardButton(text="🏁 Завершить", callback_data=f"op:finish:{order.id}")])

    rows.append([InlineKeyboardButton(text="🔄 Обновить", callback_data=f"op:open:{order.id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
