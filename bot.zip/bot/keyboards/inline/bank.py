from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def banks_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Т-Банк", callback_data="bank:tbank"),
            InlineKeyboardButton(text="Сбер", callback_data="bank:sber"),
        ],
        [
            InlineKeyboardButton(text="Альфа", callback_data="bank:alfa"),
            InlineKeyboardButton(text="СБП", callback_data="bank:sbp"),
        ],
    ])
