from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def payment_confirm_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🧾 Я оплатил", callback_data="pay:done"),
            InlineKeyboardButton(text="❌ Отменить", callback_data="pay:cancel"),
        ]
    ])
