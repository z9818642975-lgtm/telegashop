from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def cart_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Оформить заказ", callback_data="order:create")],
        [InlineKeyboardButton(text="🗑 Очистить корзину", callback_data="cart:clear")]
    ])
