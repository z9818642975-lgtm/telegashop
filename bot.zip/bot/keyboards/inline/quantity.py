from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def quantity_kb():
    rows = [
        [InlineKeyboardButton(text=str(i), callback_data=f"qty:{i}") for i in range(1, 6)],
        [InlineKeyboardButton(text=str(i), callback_data=f"qty:{i}") for i in range(6, 11)],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)
