from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def catalog_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎮 Мяу — 3500 ₽", callback_data="prod:мяу"),
         InlineKeyboardButton(text="📚 Кок — 11000 ₽", callback_data="prod:кок")],
        [InlineKeyboardButton(text="🎨 Бош — 1800 ₽", callback_data="prod:бош"),
         InlineKeyboardButton(text="⚽ Гар — 1800 ₽", callback_data="prod:гар")],
        [InlineKeyboardButton(text="🍫 Экс — 1600 ₽", callback_data="prod:экс"),
         InlineKeyboardButton(text="🤖 Лир — 4000 ₽", callback_data="prod:лир")],
        [InlineKeyboardButton(text="✅ Оформить", callback_data="cart:checkout"),
         InlineKeyboardButton(text="🧹 Очистить", callback_data="cart:clear")],
    ])
