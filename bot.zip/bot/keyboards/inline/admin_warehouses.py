from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🏬 Склады", callback_data="admin:wh:list"),
                InlineKeyboardButton(text="👥 Операторы", callback_data="admin:op:list"),
            ],
            [
                InlineKeyboardButton(text="🔄 Перемещения", callback_data="admin:tr:start"),
                InlineKeyboardButton(text="📊 Остатки", callback_data="admin:stock:view"),
            ],
        ]
    )


def warehouses_list_kb(warehouses) -> InlineKeyboardMarkup:
    rows = []
    for w in warehouses:
        rows.append([
            InlineKeyboardButton(text=f"#{w.id} {w.title}", callback_data=f"admin:wh:open:{w.id}")
        ])
    rows.append([
        InlineKeyboardButton(text="➕ Создать склад", callback_data="admin:wh:create"),
        InlineKeyboardButton(text="⬅️ Назад", callback_data="admin:home"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def warehouse_manage_kb(warehouse_id: int, is_active: bool) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✏️ Адрес", callback_data=f"admin:wh:addr:{warehouse_id}"),
                InlineKeyboardButton(text="🗄 Архивировать" if is_active else "♻️ Восстановить",
                                     callback_data=f"admin:wh:toggle:{warehouse_id}"),
            ],
            [
                InlineKeyboardButton(text="⬅️ К складам", callback_data="admin:wh:list"),
                InlineKeyboardButton(text="🏠 Домой", callback_data="admin:home"),
            ],
        ]
    )


def operators_list_kb(ops) -> InlineKeyboardMarkup:
    rows = []
    for o in ops:
        rows.append([
            InlineKeyboardButton(text=f"{'🟢' if o.is_active else '🔴'} {o.name} ({o.tg_id})",
                                 callback_data=f"admin:op:open:{o.tg_id}")
        ])
    rows.append([
        InlineKeyboardButton(text="➕ Добавить оператора", callback_data="admin:op:add"),
        InlineKeyboardButton(text="⬅️ Назад", callback_data="admin:home"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def operator_manage_kb(tg_id: int, active: bool) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🗄 Архивировать" if active else "♻️ Восстановить",
                                     callback_data=f"admin:op:toggle:{tg_id}"),
            ],
            [
                InlineKeyboardButton(text="⬅️ К операторам", callback_data="admin:op:list"),
                InlineKeyboardButton(text="🏠 Домой", callback_data="admin:home"),
            ],
        ]
    )
