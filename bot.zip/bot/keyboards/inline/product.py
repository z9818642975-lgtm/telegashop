from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def products_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Мяу", callback_data="product:meow"),
            InlineKeyboardButton(text="Кок", callback_data="product:coke"),
        ],
        [
            InlineKeyboardButton(text="Гаш", callback_data="product:gash"),
        ],
        [
            InlineKeyboardButton(text="➡️ Далее", callback_data="product:done"),
        ]
    ])
