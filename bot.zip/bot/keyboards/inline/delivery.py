from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def delivery_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🚚 Доставка", callback_data="delivery:delivery"),
            InlineKeyboardButton(text="📍 Самовывоз", callback_data="delivery:pickup"),
        ]
    ])
