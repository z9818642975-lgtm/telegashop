# -*- coding: utf-8 -*-
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


# 🔘 КНОПКИ (INLINE) — КАК В V72

def products_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Мяу", callback_data="order:product:MEOW")],
            [InlineKeyboardButton(text="Кок", callback_data="order:product:KOK")],
            [InlineKeyboardButton(text="Гаш", callback_data="order:product:GASH")],
        ]
    )


def qty_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="1–5", callback_data="order:qty:1_5")],
            [InlineKeyboardButton(text="6–10", callback_data="order:qty:6_10")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="order:back_products")],
        ]
    )


def delivery_type_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚚 Доставка", callback_data="order:delivery:DELIVERY")],
            [InlineKeyboardButton(text="📍 Самовывоз", callback_data="order:delivery:PICKUP")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="order:back_products")],
        ]
    )


def delivery_price_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="1000 ₽", callback_data="order:delivery_price:1000")],
            [InlineKeyboardButton(text="1500 ₽", callback_data="order:delivery_price:1500")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="order:delivery:DELIVERY")],
        ]
    )


def bank_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Т-Банк", callback_data="order:bank:TINKOFF"),
                InlineKeyboardButton(text="Сбер", callback_data="order:bank:SBER"),
            ],
            [
                InlineKeyboardButton(text="Альфа", callback_data="order:bank:ALFA"),
                InlineKeyboardButton(text="СБП", callback_data="order:bank:SBP"),
            ],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data="order:back_products")],
        ]
    )


def payment_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Я оплатил", callback_data="order:paid")],
            [InlineKeyboardButton(text="❌ Отменить", callback_data="order:cancel")],
        ]
    )
