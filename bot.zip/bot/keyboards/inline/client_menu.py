
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def client_menu_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📦 Каталог", callback_data="menu:catalog"),
         InlineKeyboardButton(text="🧺 Корзина", callback_data="menu:cart")],
        [InlineKeyboardButton(text="👤 Профиль", callback_data="menu:profile"),
         InlineKeyboardButton(text="❓ FAQ", callback_data="menu:faq")],
        [InlineKeyboardButton(text="💬 Связь с оператором", callback_data="menu:chat")],
    ])
