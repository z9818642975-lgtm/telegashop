from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def delivery_price_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="1000 ₽", callback_data="delprice:1000"),
         InlineKeyboardButton(text="1500 ₽", callback_data="delprice:1500")],
    ])