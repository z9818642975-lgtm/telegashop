# -*- coding: utf-8 -*-
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_panel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📦 Заказы", callback_data="admin:orders")],
            [InlineKeyboardButton(text="👷 Операторы", callback_data="admin:operators")],
            [InlineKeyboardButton(text="🏦 Банки", callback_data="admin:banks")],
        ]
    )