from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def confirm_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Я оплатил", callback_data="paid")],
        [InlineKeyboardButton(text="❌ Отменить", callback_data="cancel")]
    ])