# -*- coding: utf-8 -*-
# ============================================================
# bot/keyboards/reply/client_menu.py
# ============================================================

from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


client_main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📦 Каталог")],
        [KeyboardButton(text="🧺 Корзина")],
        [KeyboardButton(text="👤 Профиль")],
    ],
    resize_keyboard=True,
)
