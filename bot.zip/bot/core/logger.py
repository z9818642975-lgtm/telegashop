import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger("telegashop")
logging.getLogger("aiogram.event").setLevel(logging.WARNING)
