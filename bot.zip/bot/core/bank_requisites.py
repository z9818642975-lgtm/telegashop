# -*- coding: utf-8 -*-
"""Static bank requisites (V1).

Project currently runs without a full bank balancer/DB-seeded accounts.
To make the payment step work out-of-the-box, we show requisites from
this mapping.

You can later replace this with DB-driven accounts (bank_accounts table)
and load-balancing.
"""

from __future__ import annotations


# IMPORTANT: No receiver name in requisites (per project rules).
BANK_REQUISITES: dict[str, dict[str, str]] = {
    # bank code: {"title": ..., "card": ..., "sbp": ...}
    "sber": {
        "title": "Сбербанк",
        "card": "2202208208297771",
        "sbp": "9331642369",
    },
    "tbank": {
        "title": "Т‑Банк",
        "card": "2200700988565783",
        "sbp": "9818642975",
    },
    "alfa": {
        "title": "Альфа‑Банк",
        "card": "",
        "sbp": "",
    },
    "sbp": {
        "title": "СБП",
        "sbp": "9331642369",
        "card": "",
    },
}


def render_requisites(bank_code: str) -> str:
    """Return human readable requisites block for выбранный банк."""
    code = (bank_code or "").strip().lower()
    rec = BANK_REQUISITES.get(code)
    if not rec:
        return "❌ Реквизиты для этого банка пока не настроены."

    title = rec.get("title") or code
    lines: list[str] = [f"🏦 <b>{title}</b>"]

    card = (rec.get("card") or "").strip()
    sbp = (rec.get("sbp") or "").strip()

    if card:
        lines.append(f"💳 Карта: <code>{card}</code>")
    if sbp:
        lines.append(f"📲 СБП: <code>{sbp}</code>")

    if len(lines) == 1:
        return "❌ Реквизиты для этого банка пока не заполнены."
    return "\n".join(lines)
