
from bot.core.db import engine, Base

async def init_db() -> None:
    import bot.models  # noqa
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
