# -*- coding: utf-8 -*-
# ============================================================
# bot/core/schema.py
# Автосоздание схемы БД без Alembic
# ============================================================

from __future__ import annotations

from bot.core.logger import logger
from bot.core.db import Base, engine

# Важно: импорт моделей, чтобы они зарегистрировались в Base.metadata
import bot.models  # noqa: F401


async def create_all_tables() -> None:
    """
    Создаёт все таблицы/индексы/констрейнты из SQLAlchemy моделей.
    Работает безопасно: checkfirst=True (не пытается создать то, что уже есть).
    """
    logger.info("🧩 Creating DB schema (SQLAlchemy create_all)...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all, checkfirst=True)
    logger.info("✅ DB schema is ready")
